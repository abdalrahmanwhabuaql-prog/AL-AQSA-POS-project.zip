package com.alqsa.pos

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private const val STORE_NAME = "مكتبة الأقصى – عبدالرحمن"

private fun fmt(v: Double): String = String.format(Locale.US, "%.2f", v)

/** SQLite CURRENT_TIMESTAMP is UTC; show it in the phone's local time. */
fun localTime(utc: String): String = try {
    val parser = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
    val out = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
    out.format(parser.parse(utc) ?: Date())
} catch (_: Exception) { utc }

fun ledgerTitle(r: LedgerRow): String = when {
    r.isDebit -> if (r.note.startsWith("مستحق")) "مستحق آجل" else "دين"
    r.note.startsWith("مرتجع") -> "مرتجع"
    else -> "دفعة"
}

object InvoiceShare {
    fun statementText(type: String, name: String, rows: List<LedgerRow>, balance: Double): String = buildString {
        appendLine(STORE_NAME)
        appendLine(if (type == "customer") "كشف حساب الزبون: $name" else "كشف حساب المورد: $name")
        appendLine("------------------------")
        rows.forEach { r ->
            appendLine("${localTime(r.date).take(10)}  ${ledgerTitle(r)}  ${if (r.isDebit) "+" else "-"}${fmt(r.amount)}  (الرصيد ${fmt(r.running)})")
        }
        appendLine("------------------------")
        append("الرصيد المستحق: ${fmt(balance)} شيكل")
    }

    fun shareStatement(context: Context, type: String, name: String, rows: List<LedgerRow>, balance: Double) {
        val i = Intent(Intent.ACTION_SEND).apply { this.type = "text/plain"; putExtra(Intent.EXTRA_TEXT, statementText(type, name, rows, balance)) }
        context.startActivity(Intent.createChooser(i, "مشاركة كشف الحساب").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun netTotal(h: SaleHeader) = (h.total - h.returnedValue).coerceAtLeast(0.0)

    fun text(h: SaleHeader, lines: List<InvoiceLine>): String = buildString {
        appendLine(STORE_NAME)
        appendLine(if (h.hasInvoice) "فاتورة رقم: ${h.invoiceNo}" else "إيصال بيع رقم: ${h.id}")
        appendLine("التاريخ: ${localTime(h.createdAt)}")
        if (h.customerName.isNotBlank()) appendLine("الزبون: ${h.customerName}")
        appendLine("------------------------")
        lines.forEach { l ->
            appendLine("${l.productName}  ×${l.quantity}  =  ${fmt(l.quantity * l.unitPrice)}")
            if (l.returnedQty > 0) appendLine("   (مرتجع ${l.returnedQty})")
        }
        appendLine("------------------------")
        if (h.discount > 0.0001) appendLine("الخصم: ${fmt(h.discount)} شيكل")
        appendLine("الإجمالي: ${fmt(h.total)} شيكل")
        if (h.returnedValue > 0.0001) {
            appendLine("المرتجع: ${fmt(h.returnedValue)} شيكل")
            appendLine("الصافي: ${fmt(netTotal(h))} شيكل")
        }
        appendLine("المدفوع: ${fmt(h.paid)} شيكل")
        if (h.paid > 0.0001) appendLine("طريقة الدفع: ${PayMethod.label(h.payMethod)}")
        val due = netTotal(h) - h.paid
        if (due > 0.0001) appendLine("المتبقي: ${fmt(due)} شيكل")
        append("شكراً لتعاملكم معنا")
    }

    fun shareText(context: Context, h: SaleHeader, lines: List<InvoiceLine>) {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text(h, lines)) }
        context.startActivity(Intent.createChooser(i, "مشاركة الفاتورة").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun sharePdf(context: Context, h: SaleHeader, lines: List<InvoiceLine>) {
        try {
            val dir = File(context.cacheDir, "invoices").apply { mkdirs() }
            val file = File(dir, "${h.invoiceNo}.pdf")
            FileOutputStream(file).use { writePdf(it, h, lines) }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri("", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(i, "مشاركة أو طباعة الفاتورة").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(context, "تعذر إنشاء ملف الفاتورة: ${e.message ?: ""}", Toast.LENGTH_LONG).show()
        }
    }

    private fun writePdf(out: java.io.OutputStream, h: SaleHeader, lines: List<InvoiceLine>) {
        val w = 420; val ph = 595; val m = 28f
        val doc = PdfDocument()
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = 11f }
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(w, ph, pageNo).create())
        var y = 44f

        fun draw(text: String, x: Float, align: Paint.Align, size: Float = 11f, bold: Boolean = false) {
            paint.textAlign = align; paint.textSize = size
            paint.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            page.canvas.drawText(text, x, y, paint)
        }
        fun rule() { paint.strokeWidth = 0.8f; page.canvas.drawLine(m, y, w - m, y, paint); y += 14f }
        fun newPageIfNeeded(need: Float) {
            if (y + need > ph - 40) {
                doc.finishPage(page); pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(w, ph, pageNo).create()); y = 44f
            }
        }

        draw(STORE_NAME, w / 2f, Paint.Align.CENTER, 18f, true); y += 26f
        draw(if (h.hasInvoice) "فاتورة رقم: ${h.invoiceNo}" else "إيصال بيع رقم: ${h.id}", w - m, Paint.Align.RIGHT); y += 17f
        draw("التاريخ: ${localTime(h.createdAt)}", w - m, Paint.Align.RIGHT); y += 17f
        if (h.customerName.isNotBlank()) {
            draw("الزبون: ${h.customerName}${if (h.customerPhone.isNotBlank()) "  •  ${h.customerPhone}" else ""}", w - m, Paint.Align.RIGHT); y += 17f
        }
        y += 4f; rule()
        draw("الصنف", w - m, Paint.Align.RIGHT, 11f, true)
        draw("الكمية", 215f, Paint.Align.CENTER, 11f, true)
        draw("السعر", 150f, Paint.Align.CENTER, 11f, true)
        draw("المجموع", m, Paint.Align.LEFT, 11f, true)
        y += 8f; rule()

        lines.forEach { l ->
            newPageIfNeeded(34f)
            paint.textSize = 11f; paint.typeface = Typeface.DEFAULT
            val n = paint.breakText(l.productName, true, 150f, null)
            val name = if (n < l.productName.length) l.productName.take(n) + "…" else l.productName
            draw(name, w - m, Paint.Align.RIGHT)
            draw(l.quantity.toString(), 215f, Paint.Align.CENTER)
            draw(fmt(l.unitPrice), 150f, Paint.Align.CENTER)
            draw(fmt(l.quantity * l.unitPrice), m, Paint.Align.LEFT)
            y += 16f
            if (l.returnedQty > 0) { draw("مرتجع ${l.returnedQty}", w - m, Paint.Align.RIGHT, 9f); y += 13f }
        }
        newPageIfNeeded(110f)
        y += 2f; rule()
        if (h.discount > 0.0001) { draw("الخصم: ${fmt(h.discount)} شيكل", w - m, Paint.Align.RIGHT); y += 17f }
        draw("الإجمالي: ${fmt(h.total)} شيكل", w - m, Paint.Align.RIGHT, 13f, true); y += 19f
        if (h.returnedValue > 0.0001) {
            draw("المرتجع: ${fmt(h.returnedValue)} شيكل", w - m, Paint.Align.RIGHT); y += 17f
            draw("الصافي: ${fmt(netTotal(h))} شيكل", w - m, Paint.Align.RIGHT, 12f, true); y += 18f
        }
        draw("المدفوع: ${fmt(h.paid)} شيكل", w - m, Paint.Align.RIGHT); y += 17f
        if (h.paid > 0.0001) { draw("طريقة الدفع: ${PayMethod.label(h.payMethod)}", w - m, Paint.Align.RIGHT); y += 17f }
        val due = netTotal(h) - h.paid
        if (due > 0.0001) { draw("المتبقي: ${fmt(due)} شيكل", w - m, Paint.Align.RIGHT, 12f, true); y += 18f }
        y += 10f
        draw("شكراً لتعاملكم معنا", w / 2f, Paint.Align.CENTER, 11f)
        doc.finishPage(page)
        doc.writeTo(out)
        doc.close()
    }
}
