package com.alqsa.pos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.util.Locale

private val DeepGreen = Color(0xFF123D32)
private val Gold = Color(0xFFD6AD45)

class MainActivity : ComponentActivity() {
    private lateinit var db: StoreDb

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = StoreDb(this)
        setContent { AlAqsaApp(db) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlAqsaApp(db: StoreDb) {
    var products by remember { mutableStateOf(db.products()) }
    var showAdd by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }
    var message by remember { mutableStateOf("") }
    val salesToday = remember(products) { db.todaySalesTotal() }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = DeepGreen,
        secondary = Gold,
        background = Color(0xFFFFFCF4)
    )) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("مكتبة الأقصى", fontWeight = FontWeight.Bold)
                            Text("AL-AQSA POS", style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = DeepGreen,
                        titleContentColor = Color.White
                    )
                )
            },
            floatingActionButton = {
                if (tab == 1) FloatingActionButton(
                    onClick = { showAdd = true },
                    containerColor = DeepGreen,
                    contentColor = Color.White
                ) { Icon(Icons.Default.Add, contentDescription = "إضافة منتج") }
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.PointOfSale, null) },
                        label = { Text("الكاشير") }
                    )
                    NavigationBarItem(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.Inventory2, null) },
                        label = { Text("المنتجات") }
                    )
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = DeepGreen)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Text("مبيعات اليوم", color = Color.White)
                        Text("${money(salesToday)} شيكل", color = Gold, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("يعمل محلياً دون إنترنت", color = Color.White.copy(alpha = .8f))
                    }
                }
                Spacer(Modifier.height(16.dp))
                if (tab == 0) {
                    Text("بيع سريع", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    if (products.isEmpty()) {
                        EmptyState("لا توجد منتجات بعد", "انتقل إلى المنتجات وأضف أول صنف للمكتبة.")
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(products, key = { it.id }) { p ->
                                ProductRow(p, actionLabel = "بيع قطعة") {
                                    val ok = db.sellOne(p)
                                    products = db.products()
                                    message = if (ok) "تم تسجيل بيع ${p.name}" else "الكمية غير متوفرة"
                                }
                            }
                        }
                    }
                } else {
                    Text("مخزون المنتجات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    if (products.isEmpty()) EmptyState("المخزون فارغ", "اضغط + لإضافة منتج جديد.")
                    else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(products, key = { it.id }) { p -> ProductRow(p, null, null) }
                    }
                }
            }
        }

        if (showAdd) {
            AddProductDialog(
                onDismiss = { showAdd = false },
                onSave = { name, barcode, buy, sell, qty ->
                    db.addProduct(name, barcode, buy, sell, qty)
                    products = db.products()
                    showAdd = false
                }
            )
        }
        if (message.isNotBlank()) {
            AlertDialog(
                onDismissRequest = { message = "" },
                confirmButton = { TextButton(onClick = { message = "" }) { Text("حسناً") } },
                text = { Text(message) }
            )
        }
    }
}

@Composable
private fun ProductRow(product: Product, actionLabel: String?, onAction: (() -> Unit)?) {
    Card {
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(product.name, fontWeight = FontWeight.Bold)
                Text("الكمية: ${product.quantity}  •  السعر: ${money(product.sellPrice)} شيكل",
                    style = MaterialTheme.typography.bodySmall)
                if (product.barcode.isNotBlank()) Text("باركود: ${product.barcode}", style = MaterialTheme.typography.labelSmall)
            }
            if (actionLabel != null && onAction != null) {
                Button(onClick = onAction, colors = ButtonDefaults.buttonColors(containerColor = DeepGreen)) {
                    Text(actionLabel)
                }
            }
        }
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun AddProductDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, Double, Double, Int) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var barcode by remember { mutableStateOf("") }
    var buy by remember { mutableStateOf("0") }
    var sell by remember { mutableStateOf("0") }
    var qty by remember { mutableStateOf("0") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة منتج") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم المنتج") }, singleLine = true)
                OutlinedTextField(barcode, { barcode = it }, label = { Text("الباركود (اختياري)") }, singleLine = true)
                OutlinedTextField(buy, { buy = it }, label = { Text("سعر الشراء") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(sell, { sell = it }, label = { Text("سعر البيع") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(qty, { qty = it }, label = { Text("الكمية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    onSave(name, barcode, buy.toDoubleOrNull() ?: 0.0, sell.toDoubleOrNull() ?: 0.0, qty.toIntOrNull() ?: 0)
                }
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

private fun money(value: Double): String = String.format(Locale.US, "%.2f", value)
