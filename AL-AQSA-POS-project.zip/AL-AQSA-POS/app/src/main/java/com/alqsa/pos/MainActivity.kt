package com.alqsa.pos

import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.util.Locale

private val Green = Color(0xFF123D32)
private val Gold = Color(0xFFD6AD45)
private val Cream = Color(0xFFFFFCF4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = StoreDb(this)
        setContent { AlAqsaApp(db) }
    }
}

private enum class Page(val title: String) {
    HOME("الرئيسية"), SALES("الكاشير"), PRODUCTS("المخزون"),
    PURCHASES("المشتريات"), FINANCE("التقارير"), DEBTS("الديون"), CASHBOX("الصندوق")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlAqsaApp(db: StoreDb) {
    var page by remember { mutableStateOf(Page.HOME) }
    var products by remember { mutableStateOf(db.products()) }
    var refresh by remember { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Product?>(null) }
    var message by remember { mutableStateOf("") }
    val summary = remember(refresh) { db.summary() }
    val expenses = remember(refresh) { db.expenses() }
    val sales = remember(refresh) { db.salesHistory() }
    fun reload() { products = db.products(); refresh++ }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Green, secondary = Gold, background = Cream,
        surface = Color.White
    )) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Column {
                        Text("مكتبة الأقصى", fontWeight = FontWeight.Bold)
                        Text("AL-AQSA POS  •  الإصدار 1.0 FINAL", style = MaterialTheme.typography.labelSmall)
                    }},
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Green, titleContentColor = Color.White
                    )
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf(Page.HOME, Page.SALES, Page.PRODUCTS, Page.PURCHASES, Page.FINANCE, Page.DEBTS, Page.CASHBOX).forEach { p ->
                        val icon = when (p) {
                            Page.HOME -> Icons.Default.Dashboard
                            Page.SALES -> Icons.Default.PointOfSale
                            Page.PRODUCTS -> Icons.Default.Inventory2
                            Page.PURCHASES -> Icons.Default.LocalShipping
                            Page.FINANCE -> Icons.Default.Assessment
                            Page.DEBTS -> Icons.Default.AccountBalanceWallet
                            Page.CASHBOX -> Icons.Default.Payments
                        }
                        NavigationBarItem(
                            selected = page == p, onClick = { page = p },
                            icon = { Icon(icon, contentDescription = p.title) },
                            label = { Text(p.title, maxLines = 1) }
                        )
                    }
                }
            },
            floatingActionButton = {
                if (page == Page.PRODUCTS) FloatingActionButton(
                    onClick = { selected = null; dialog = "product" },
                    containerColor = Green, contentColor = Color.White
                ) { Icon(Icons.Default.Add, contentDescription = "إضافة منتج") }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp, vertical = 10.dp)) {
                when (page) {
                    Page.HOME -> HomePage(summary, onNavigate = { page = it })
                    Page.SALES -> SalesPage(products, onSell = { p, qty, unitPrice, invoice, paid ->
                        val saleId = db.checkout(listOf(p to (qty to unitPrice)), invoice, paid)
                        reload()
                        message = if (saleId > 0) "تم تسجيل البيع رقم $saleId" else "تعذر البيع: تحقق من المخزون والمبلغ المدفوع"
                    })
                    Page.PRODUCTS -> ProductsPage(products, onEdit = { selected = it; dialog = "product" })
                    Page.PURCHASES -> PurchasesPage(products, onPurchase = { p, qty, cost, supplier, paid ->
                        val ok = db.addPurchase(p.id, qty, cost, supplier, paid)
                        reload()
                        message = if (ok) "تم تسجيل المشتريات وتحديث المخزون" else "تعذر تسجيل المشتريات"
                    })
                    Page.FINANCE -> FinancePage(summary, expenses, sales, onExpense = { dialog = "expense" }, onDebts = { page = Page.DEBTS }, onCash = { page = Page.CASHBOX })
                    Page.DEBTS -> DebtsPage(db, refresh, onChanged = { reload(); message = it })
                    Page.CASHBOX -> CashboxPage(db, refresh, onChanged = { reload(); message = it })
                }
            }
        }

        if (dialog == "product") ProductDialog(selected, onDismiss = { dialog = "" }) { p ->
            if (selected == null) db.addProduct(p.name, p.barcode, p.buy, p.sell, p.qty, p.unit, p.pack, p.packSell)
            else db.updateProduct(selected!!.id, p.name, p.barcode, p.buy, p.sell, p.qty, p.unit, p.pack, p.packSell)
            dialog = ""; reload()
        }
        if (dialog == "expense") ExpenseDialog(onDismiss = { dialog = "" }) { title, amount, note ->
            db.addExpense(title, amount, note); dialog = ""; reload()
            message = "تم تسجيل المصروف"
        }
        if (message.isNotBlank()) AlertDialog(
            onDismissRequest = { message = "" },
            confirmButton = { TextButton(onClick = { message = "" }) { Text("حسناً") } },
            text = { Text(message) }
        )
    }
}

@Composable
private fun HomePage(s: Summary, onNavigate: (Page) -> Unit) {
    Text("أهلاً بك في إدارة المكتبة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    Text("ملخص العمل اليومي", color = Color.Gray)
    Spacer(Modifier.height(12.dp))
    Card(colors = CardDefaults.cardColors(containerColor = Green), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("مبيعات اليوم", color = Color.White)
            Text("${money(s.sales)} شيكل", color = Gold, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("الربح الإجمالي التقديري: ${money(s.sales - s.cost)} شيكل", color = Color.White)
        }
    }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MetricCard("عدد الأصناف", s.products.toString(), Modifier.weight(1f))
        MetricCard("وحدات المخزون", s.stockUnits.toString(), Modifier.weight(1f))
    }
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MetricCard("مصروفات اليوم", money(s.expenses), Modifier.weight(1f))
        MetricCard("أصناف منخفضة", s.lowStock.toString(), Modifier.weight(1f))
    }
    Spacer(Modifier.height(16.dp))
    Text("الوصول السريع", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    listOf(Page.SALES, Page.PRODUCTS, Page.PURCHASES, Page.FINANCE).chunked(2).forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            row.forEach { p ->
                Button(onClick = { onNavigate(p) }, modifier = Modifier.weight(1f).height(54.dp)) {
                    Text(p.title)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
    Text("يعمل الكاشير محلياً دون إنترنت", color = Green, style = MaterialTheme.typography.labelMedium)
}

@Composable
private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Text(title, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Green)
        }
    }
}

@Composable
private fun SalesPage(products: List<Product>, onSell: (Product, Int, Double, Boolean, Double) -> Unit) {
    var query by remember { mutableStateOf("") }
    var showScanner by remember { mutableStateOf(false) }
    var cameraError by remember { mutableStateOf("") }
    var pendingSale by remember { mutableStateOf<Triple<Product, Int, Double>?>(null) }
    var invoiceChoice by remember { mutableStateOf(true) }
    var paidText by remember { mutableStateOf("") }
    val context = LocalContext.current
    var hasCameraPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasCameraPermission = granted
        if (granted) showScanner = true else cameraError = "لم يتم منح إذن الكاميرا. فعّل الإذن من إعدادات التطبيق."
    }
    Text("الكاشير والبيع السريع", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(),
        label = { Text("ابحث باسم المنتج أو أدخل الباركود") }, singleLine = true,
        leadingIcon = { Icon(Icons.Default.Search, null) })
    Spacer(Modifier.height(7.dp))
    Button(onClick = {
        if (hasCameraPermission) showScanner = true
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }, modifier = Modifier.fillMaxWidth().height(48.dp)) {
        Icon(Icons.Default.QrCodeScanner, contentDescription = null)
        Spacer(Modifier.width(8.dp)); Text("مسح الباركود بالكاميرا")
    }
    Spacer(Modifier.height(8.dp))
    val filtered = products.filter { it.name.contains(query, true) || (query.isNotBlank() && it.barcode.contains(query, true)) }
    if (filtered.isEmpty()) Empty("لا توجد نتائج", "أضف المنتجات أو امسح باركود صنف مسجل.")
    else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(filtered, key = { it.id }) { p ->
            var qty by remember(p.id) { mutableStateOf("1") }
            var packMode by remember(p.id) { mutableStateOf(false) }
            val factor = if (packMode) p.packSize.coerceAtLeast(1) else 1
            val requested = (qty.toIntOrNull() ?: 1) * factor
            Card {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text(p.name, fontWeight = FontWeight.Bold)
                    Text("المتوفر: ${p.quantity} قطعة  •  سعر القطعة: ${money(p.sellPrice)} شيكل")
                    if (p.packSize > 1) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("طريقة البيع:")
                            Spacer(Modifier.width(8.dp))
                            FilterChip(selected = !packMode, onClick = { packMode = false }, label = { Text("قطعة") })
                            Spacer(Modifier.width(6.dp))
                            FilterChip(selected = packMode, onClick = { packMode = true }, label = { Text("علبة × ${p.packSize}") })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(qty, { qty = it.filter(Char::isDigit) },
                            modifier = Modifier.weight(1f), label = { Text(if (packMode) "عدد العلب" else "الكمية") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { pendingSale = Triple(p, requested, if (packMode) p.packSellPrice / p.packSize.coerceAtLeast(1) else p.sellPrice); invoiceChoice = true; paidText = (requested * (if (packMode) p.packSellPrice / p.packSize.coerceAtLeast(1) else p.sellPrice)).toString() }, enabled = requested > 0 && requested <= p.quantity) { Text("إتمام البيع") }
                    }
                    if (packMode) Text("سعر العبوة: ${money(p.packSellPrice)} شيكل • سيتم خصم $requested قطعة", color = Green, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
    pendingSale?.let { sale ->
        val total = sale.second * sale.third
        AlertDialog(onDismissRequest = { pendingSale = null },
            title = { Text("طريقة تسجيل البيع") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${sale.first.name} • الكمية ${sale.second} • الإجمالي ${money(total)} شيكل")
                Text("اختر طريقة تسجيل العملية:")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = invoiceChoice, onClick = { invoiceChoice = true }, label = { Text("فاتورة سريعة") })
                    FilterChip(selected = !invoiceChoice, onClick = { invoiceChoice = false }, label = { Text("بدون فاتورة") })
                }
                OutlinedTextField(paidText, { paidText = it }, label = { Text("المبلغ المدفوع (شيكل)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                Text("المتبقي سيُسجّل دينًا على الزبون تلقائيًا. لا يلزم اسم أو رقم هاتف.", color = Green, style = MaterialTheme.typography.bodySmall)
            }},
            confirmButton = { TextButton(enabled = (paidText.toDoubleOrNull() ?: -1.0) in 0.0..total, onClick = {
                onSell(sale.first, sale.second, sale.third, invoiceChoice, paidText.toDoubleOrNull() ?: 0.0); pendingSale = null
            }) { Text("تأكيد البيع") } },
            dismissButton = { TextButton(onClick = { pendingSale = null }) { Text("إلغاء") } })
    }
    if (cameraError.isNotBlank()) AlertDialog(onDismissRequest = { cameraError = "" },
        confirmButton = { TextButton(onClick = { cameraError = "" }) { Text("حسناً") } }, text = { Text(cameraError) })
    if (showScanner) BarcodeScannerDialog(onDismiss = { showScanner = false }, onBarcode = { code ->
        query = code
        showScanner = false
    })
}

@OptIn(ExperimentalGetImage::class)
@Composable
private fun BarcodeScannerDialog(onDismiss: () -> Unit, onBarcode: (String) -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val executor = remember { Executors.newSingleThreadExecutor() }
    val handled = remember { AtomicBoolean(false) }
    var status by remember { mutableStateOf("وجّه الكاميرا نحو الباركود") }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxWidth(0.96f).fillMaxHeight(0.78f), shape = MaterialTheme.shapes.large) {
            Column(Modifier.padding(12.dp)) {
                Text("ماسح الباركود", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(status, color = Green)
                Spacer(Modifier.height(8.dp))
                AndroidView(factory = { ctx ->
                    val previewView = PreviewView(ctx).apply {
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                        implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                    }
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        try {
                            val cameraProvider = cameraProviderFuture.get()
                            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                            val scanner = BarcodeScanning.getClient()
                            val analysis = ImageAnalysis.Builder()
                                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                            analysis.setAnalyzer(executor) { imageProxy ->
                                val mediaImage = imageProxy.image
                                if (mediaImage == null || handled.get()) {
                                    imageProxy.close()
                                } else {
                                    val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                                    scanner.process(image)
                                        .addOnSuccessListener { barcodes ->
                                            val value = barcodes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
                                            if (value != null && handled.compareAndSet(false, true)) {
                                                previewView.post { onBarcode(value) }
                                            }
                                        }
                                        .addOnFailureListener { status = "تعذرت قراءة الرمز، قرّب الكاميرا وحاول مجدداً" }
                                        .addOnCompleteListener { imageProxy.close() }
                                }
                            }
                            cameraProvider.unbindAll()
                            cameraProvider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                        } catch (e: Exception) {
                            status = "تعذر تشغيل الكاميرا: ${e.localizedMessage ?: "خطأ غير معروف"}"
                        }
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                }, modifier = Modifier.weight(1f).fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("إغلاق الماسح") }
            }
        }
    }
    DisposableEffect(lifecycleOwner) {
        onDispose {
            try { ProcessCameraProvider.getInstance(context).get().unbindAll() } catch (_: Exception) {}
            executor.shutdown()
        }
    }
}

@Composable
private fun ProductsPage(products: List<Product>, onEdit: (Product) -> Unit) {
    Text("إدارة المنتجات والمخزون", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    Text("اضغط على المنتج لتعديل بياناته", color = Color.Gray)
    Spacer(Modifier.height(8.dp))
    if (products.isEmpty()) Empty("المخزون فارغ", "اضغط زر + لإضافة أول منتج.")
    else LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        items(products, key = { it.id }) { p ->
            Card(onClick = { onEdit(p) }) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.Bold)
                        Text("شراء ${money(p.buyPrice)}  •  بيع ${money(p.sellPrice)} شيكل")
                        Text("المخزون: ${p.quantity} ${p.unitName}  •  حجم العبوة: ${p.packSize}",
                            style = MaterialTheme.typography.bodySmall)
                        if (p.barcode.isNotBlank()) Text("باركود: ${p.barcode}", style = MaterialTheme.typography.labelSmall)
                    }
                    Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = Green)
                }
            }
        }
    }
}

@Composable
private fun PurchasesPage(products: List<Product>, onPurchase: (Product, Int, Double, String, Double) -> Unit) {
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var qty by remember { mutableStateOf("1") }
    var cost by remember { mutableStateOf("0") }
    var supplier by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("0") }
    Text("تسجيل المشتريات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    Text("اختر صنفاً، ثم أدخل الكمية وسعر شراء الوحدة.", color = Color.Gray)
    Spacer(Modifier.height(10.dp))
    if (products.isEmpty()) Empty("لا توجد منتجات", "أضف الصنف أولاً من شاشة المخزون.")
    else {
        var expanded by remember { mutableStateOf(false) }
        val selected = products.firstOrNull { it.id == selectedId }
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(selected?.name ?: "اختر المنتج")
        }
        DropdownMenu(expanded, { expanded = false }) {
            products.forEach { p -> DropdownMenuItem(text = { Text(p.name) }, onClick = {
                selectedId = p.id; cost = p.buyPrice.toString(); expanded = false
            }) }
        }
        OutlinedTextField(qty, { qty = it.filter(Char::isDigit) }, label = { Text("الكمية المضافة") },
            modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        OutlinedTextField(cost, { cost = it }, label = { Text("سعر شراء القطعة") },
            modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        OutlinedTextField(supplier, { supplier = it }, label = { Text("اسم المورد (اختياري)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(paid, { paid = it }, label = { Text("المبلغ المدفوع للمورد") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        Text("الإجمالي: ${money((qty.toIntOrNull() ?: 0) * (cost.toDoubleOrNull() ?: 0.0))} شيكل • المتبقي يسجل دينًا للمورد إذا أدخلت اسمه", color = Green, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(10.dp))
        Button(onClick = {
            if (selected != null) onPurchase(selected, qty.toIntOrNull() ?: 0, cost.toDoubleOrNull() ?: -1.0, supplier, paid.toDoubleOrNull() ?: 0.0)
        }, enabled = selected != null && (paid.toDoubleOrNull() ?: -1.0) >= 0 && (paid.toDoubleOrNull() ?: 0.0) <= (qty.toIntOrNull() ?: 0) * (cost.toDoubleOrNull() ?: 0.0), modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("حفظ المشتريات وتحديث المخزون") }
    }
}

@Composable
private fun FinancePage(s: Summary, expenses: List<Expense>, sales: List<SaleLine>, onExpense: () -> Unit, onDebts: () -> Unit, onCash: () -> Unit) {
    Text("المصاريف والتقارير", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("ملخص اليوم", fontWeight = FontWeight.Bold)
            ReportLine("إجمالي المبيعات", s.sales)
            ReportLine("تكلفة البضاعة المباعة", s.cost)
            ReportLine("الربح قبل المصروفات", s.sales - s.cost)
            ReportLine("المصروفات", s.expenses)
            Divider()
            ReportLine("صافي الربح التقديري", s.sales - s.cost - s.expenses)
        }
    }
    Spacer(Modifier.height(10.dp))
    Button(onClick = onExpense, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("إضافة مصروف")
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = onDebts, modifier = Modifier.weight(1f)) { Text("إدارة الديون") }
        OutlinedButton(onClick = onCash, modifier = Modifier.weight(1f)) { Text("الصندوق") }
    }
    Spacer(Modifier.height(12.dp))
    Text("آخر المصروفات", fontWeight = FontWeight.Bold)
    if (expenses.isEmpty()) Text("لا توجد مصروفات مسجلة", color = Color.Gray)
    else LazyColumn(Modifier.heightIn(max = 150.dp)) {
        items(expenses) { e -> ListItem(headlineContent = { Text(e.title) },
            supportingContent = { Text(e.createdAt) }, trailingContent = { Text("${money(e.amount)} ₪") }) }
    }
    Text("آخر المبيعات", fontWeight = FontWeight.Bold)
    if (sales.isEmpty()) Text("لا توجد مبيعات مسجلة", color = Color.Gray)
    else LazyColumn(Modifier.heightIn(max = 190.dp)) {
        items(sales) { line -> ListItem(
            headlineContent = { Text(line.productName) },
            supportingContent = { Text("${line.quantity} قطعة • ${line.createdAt}") },
            trailingContent = { Text("${money(line.quantity * line.unitPrice)} ₪") }
        ) }
    }
}

@Composable
private fun DebtsPage(db: StoreDb, refresh: Int, onChanged: (String) -> Unit) {
    var type by remember { mutableStateOf("customer") }
    var name by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var paymentMode by remember { mutableStateOf(false) }
    val balances = remember(refresh) { db.balances().filter { it.partyType == type } }
    Column(Modifier.fillMaxSize()) {
        Text("إدارة ديون الزبائن والموردين", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = type == "customer", onClick = { type = "customer" }, label = { Text("الزبائن") })
            FilterChip(selected = type == "supplier", onClick = { type = "supplier" }, label = { Text("الموردون") })
        }
        OutlinedTextField(name, { name = it }, label = { Text(if (type == "customer") "اسم الزبون" else "اسم المورد") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(amount, { amount = it }, label = { Text("المبلغ بالشيكل") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
        OutlinedTextField(note, { note = it }, label = { Text("ملاحظة (اختياري)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { db.addDebt(type, name, amount.toDoubleOrNull() ?: 0.0, note); onChanged("تم تسجيل المبلغ المستحق"); name=""; amount=""; note="" }, enabled = name.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0) > 0, modifier = Modifier.weight(1f)) { Text("إضافة دين") }
            OutlinedButton(onClick = { paymentMode = true }, modifier = Modifier.weight(1f)) { Text("تسجيل دفعة") }
        }
        Spacer(Modifier.height(8.dp)); Text("الأرصدة المستحقة", fontWeight = FontWeight.Bold)
        if (balances.isEmpty()) Empty("لا توجد أرصدة", "ستظهر هنا ديون الزبائن أو الموردين.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(balances) { b -> Card { ListItem(headlineContent = { Text(b.partyName) }, supportingContent = { Text(if (type == "customer") "مستحق للمكتبة" else "مستحق للمورد") }, trailingContent = { Text("${money(b.balance)} ₪", fontWeight = FontWeight.Bold) }) } }
        }
    }
    if (paymentMode) AlertDialog(onDismissRequest = { paymentMode = false }, title = { Text("تسجيل دفعة") }, text = { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("أدخل اسم الشخص والمبلغ الذي دفعه أو سددته")
        OutlinedTextField(name, { name=it }, label={ Text("الاسم") })
        OutlinedTextField(amount, { amount=it }, label={ Text("المبلغ") }, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        OutlinedTextField(note, { note=it }, label={ Text("ملاحظة") })
    }}, confirmButton = { TextButton(onClick = { val ok=db.payDebt(type,name,amount.toDoubleOrNull()?:0.0,note); onChanged(if(ok) "تم تسجيل الدفعة" else "تعذر تسجيل الدفعة؛ تحقق من الاسم والرصيد"); paymentMode=false; name=""; amount=""; note="" }) { Text("حفظ الدفعة") } }, dismissButton = { TextButton(onClick={paymentMode=false}) { Text("إلغاء") } })
}

@Composable
private fun CashboxPage(db: StoreDb, refresh: Int, onChanged: (String) -> Unit) {
    var opening by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("إيداع") }
    val summary = remember(refresh) { db.cashSummary() }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("الصندوق النقدي", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Green)) { Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("الرصيد النقدي المحسوب", color = Color.White)
            Text("${money(summary.balance)} شيكل", color = Gold, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("إجمالي الداخل: ${money(summary.cashIn)} • إجمالي الخارج: ${money(summary.cashOut)}", color = Color.White)
        } }
        OutlinedTextField(opening, { opening=it }, label={ Text("تحديد رصيد افتتاحي (شيكل)") }, modifier=Modifier.fillMaxWidth(), keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        Button(onClick={ db.setOpeningCash(opening.toDoubleOrNull()?:0.0); onChanged("تم حفظ الرصيد الافتتاحي") }, modifier=Modifier.fillMaxWidth(), enabled=(opening.toDoubleOrNull()?:-1.0)>=0) { Text("حفظ الرصيد الافتتاحي") }
        Text("حركة نقدية يدوية", fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            listOf("إيداع","سحب شخصي").forEach { FilterChip(selected=kind==it,onClick={kind=it},label={Text(it)}) }
        }
        OutlinedTextField(amount,{amount=it},label={Text("المبلغ")},modifier=Modifier.fillMaxWidth(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
        OutlinedTextField(note,{note=it},label={Text("البيان")},modifier=Modifier.fillMaxWidth())
        Button(onClick={db.addCashMove(kind,amount.toDoubleOrNull()?:0.0,note); onChanged("تم تسجيل الحركة النقدية"); amount=""; note=""},enabled=(amount.toDoubleOrNull()?:0.0)>0,modifier=Modifier.fillMaxWidth()) { Text("تسجيل الحركة") }
    }
}

@Composable
private fun ReportLine(label: String, amount: Double) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label); Text("${money(amount)} شيكل", fontWeight = FontWeight.SemiBold)
    }
}

private data class ProductInput(
    val name: String, val barcode: String, val buy: Double,
    val sell: Double, val qty: Int, val unit: String, val pack: Int,
    val packSell: Double
)

@Composable
private fun ProductDialog(old: Product?, onDismiss: () -> Unit, onSave: (ProductInput) -> Unit) {
    var name by remember { mutableStateOf(old?.name ?: "") }
    var barcode by remember { mutableStateOf(old?.barcode ?: "") }
    var unit by remember { mutableStateOf(old?.unitName ?: "قطعة") }
    var pack by remember { mutableStateOf(old?.packSize?.toString() ?: "12") }
    var buyPack by remember { mutableStateOf(old?.let { money(it.buyPrice * it.packSize) } ?: "0") }
    var sell by remember { mutableStateOf(old?.sellPrice?.toString() ?: "0") }
    var sellPack by remember { mutableStateOf(old?.packSellPrice?.toString() ?: "0") }
    val packCountInitial = old?.let { it.quantity / it.packSize.coerceAtLeast(1) } ?: 0
    val looseInitial = old?.let { it.quantity % it.packSize.coerceAtLeast(1) } ?: 0
    var packsInStock by remember { mutableStateOf(packCountInitial.toString()) }
    var looseStock by remember { mutableStateOf(looseInitial.toString()) }
    val packSize = (pack.toIntOrNull() ?: 1).coerceAtLeast(1)
    val buyPackValue = buyPack.toDoubleOrNull() ?: 0.0
    val pieceCost = buyPackValue / packSize
    val totalPieces = (packsInStock.toIntOrNull() ?: 0) * packSize + (looseStock.toIntOrNull() ?: 0)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (old == null) "إضافة منتج" else "تعديل المنتج") },
        text = {
            Column(
                Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Text("1. بيانات المنتج", fontWeight = FontWeight.Bold, color = Green)
                OutlinedTextField(name, { name = it }, label = { Text("اسم المنتج") }, singleLine = true)
                OutlinedTextField(barcode, { barcode = it }, label = { Text("الباركود (يمكن مسحه من شاشة الكاشير)") }, singleLine = true)
                Text("2. بيانات العبوة والشراء", fontWeight = FontWeight.Bold, color = Green)
                OutlinedTextField(unit, { unit = it }, label = { Text("اسم القطعة (قلم/دفتر...)") }, singleLine = true)
                OutlinedTextField(pack, { pack = it.filter(Char::isDigit) }, label = { Text("عدد القطع داخل العبوة/الدستة") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(buyPack, { buyPack = it }, label = { Text("سعر شراء العبوة كاملة (شيكل)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                Text("تكلفة القطعة تلقائياً: ${money(pieceCost)} شيكل", color = Green, fontWeight = FontWeight.SemiBold)
                Text("3. أسعار البيع", fontWeight = FontWeight.Bold, color = Green)
                OutlinedTextField(sell, { sell = it }, label = { Text("سعر بيع القطعة (شيكل)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(sellPack, { sellPack = it }, label = { Text("سعر بيع العبوة كاملة (شيكل)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                Text("4. المخزون الحالي", fontWeight = FontWeight.Bold, color = Green)
                OutlinedTextField(packsInStock, { packsInStock = it.filter(Char::isDigit) }, label = { Text("عدد العبوات الموجودة") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(looseStock, { looseStock = it.filter(Char::isDigit) }, label = { Text("قطع مفردة إضافية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                Text("إجمالي المخزون: $totalPieces قطعة", color = Green, fontWeight = FontWeight.Bold)
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank() && packSize > 0, onClick = {
                val unitBuy = pieceCost
                onSave(ProductInput(
                    name, barcode, unitBuy, sell.toDoubleOrNull() ?: 0.0,
                    totalPieces, unit.ifBlank { "قطعة" }, packSize,
                    sellPack.toDoubleOrNull() ?: ((sell.toDoubleOrNull() ?: 0.0) * packSize)
                ))
            }) { Text("حفظ المنتج") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun ExpenseDialog(onDismiss: () -> Unit, onSave: (String, Double, String) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة مصروف") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("اسم المصروف") }, singleLine = true)
            OutlinedTextField(amount, { amount = it }, label = { Text("المبلغ بالشيكل") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(note, { note = it }, label = { Text("ملاحظات (اختياري)") })
        }},
        confirmButton = { TextButton(enabled = title.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0) > 0,
            onClick = { onSave(title, amount.toDoubleOrNull() ?: 0.0, note) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun Empty(title: String, subtitle: String) {
    Box(Modifier.fillMaxWidth().padding(25.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Color.Gray)
        }
    }
}

private fun money(value: Double): String = String.format(Locale.US, "%.2f", value)
