package com.alqsa.pos

import android.os.Bundle
import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.database.sqlite.SQLiteDatabase
import java.io.File
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.util.Locale

private val Green = Color(0xFF123D32)
private val Gold = Color(0xFFD6AD45)
private val Cream = Color(0xFFFFFCF4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = StoreDb(this)
        setContent { AlAqsaApp(db) }
    }
}

private enum class Page(val title: String) {
    HOME("الرئيسية"), SALES("الكاشير"), PRODUCTS("المخزون"),
    PURCHASES("المشتريات"), INVOICES("الفواتير"), FINANCE("المصاريف والملخص"), REPORTS("تقارير الفترات"),
    DEBTS("الديون"), CASHBOX("الصندوق"), BACKUP("النسخ الاحتياطي"), MORE("المزيد")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlAqsaApp(db: StoreDb) {
    var page by remember { mutableStateOf(Page.HOME) }
    var products by remember { mutableStateOf(db.products()) }
    var refresh by remember { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Product?>(null) }
    var message by remember { mutableStateOf("") }
    val purchaseDraft = remember { PurchaseDraft() }
    val summary = remember(refresh) { db.summary() }
    val expenses = remember(refresh) { db.expenses() }
    val sales = remember(refresh) { db.salesHistory() }
    val invoices = remember(refresh) { db.saleHeaders() }
    val purchaseHistory = remember(refresh) { db.purchaseHeaders() }
    val supplierNames = remember(refresh) { db.supplierNames() }
    fun reload() { products = db.products(); refresh++ }
    val context = LocalContext.current
    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) try {
            db.writableDatabase.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { it.moveToFirst() }
            context.contentResolver.openOutputStream(uri)?.use { out -> context.getDatabasePath("alqsa_pos.db").inputStream().use { it.copyTo(out) } }
            message = "تم إنشاء نسخة احتياطية من قاعدة البيانات"
        } catch (e: Exception) { message = "فشل النسخ الاحتياطي: ${e.message ?: "خطأ غير معروف"}" }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) try {
            val target = context.getDatabasePath("alqsa_pos.db")
            val temp = File(context.cacheDir, "restore_check.db")
            context.contentResolver.openInputStream(uri)?.use { input -> temp.outputStream().use { input.copyTo(it) } }
            val check = SQLiteDatabase.openDatabase(temp.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
            val valid = check.rawQuery("PRAGMA integrity_check", null).use { it.moveToFirst() && it.getString(0) == "ok" }
            check.close()
            if (!valid) throw IllegalArgumentException("ملف النسخة غير صالح")
            db.close()
            File(target.path + "-wal").delete(); File(target.path + "-shm").delete()
            temp.copyTo(target, overwrite = true); temp.delete()
            reload(); message = "تمت استعادة النسخة الاحتياطية بنجاح"
        } catch (e: Exception) { message = "تعذرت الاستعادة: ${e.message ?: "تحقق من الملف"}" }
    }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Green, secondary = Gold, background = Cream,
        surface = Color.White
    )) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Column {
                        Text("مكتبة الأقصى", fontWeight = FontWeight.Bold)
                        Text("AL-AQSA POS  •  الإصدار 1.5", style = MaterialTheme.typography.labelSmall)
                    }},
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Green, titleContentColor = Color.White
                    )
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    val main = listOf(Page.HOME, Page.SALES, Page.PRODUCTS, Page.PURCHASES)
                    (main + Page.MORE).forEach { p ->
                        val icon = when (p) {
                            Page.HOME -> Icons.Default.Dashboard
                            Page.SALES -> Icons.Default.PointOfSale
                            Page.PRODUCTS -> Icons.Default.Inventory2
                            Page.PURCHASES -> Icons.Default.LocalShipping
                            else -> Icons.Default.MoreHoriz
                        }
                        NavigationBarItem(
                            selected = if (p == Page.MORE) page !in main else page == p, onClick = { page = p },
                            icon = { Icon(icon, contentDescription = p.title) },
                            label = { Text(p.title, maxLines = 1) }
                        )
                    }
                }
            },
            floatingActionButton = {
                if (page == Page.PRODUCTS) FloatingActionButton(
                    onClick = { selected = null; dialog = "product" },
                    containerColor = Green, contentColor = Color.White
                ) { Icon(Icons.Default.Add, contentDescription = "إضافة منتج") }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp, vertical = 10.dp)) {
                when (page) {
                    Page.HOME -> HomePage(summary, onNavigate = { page = it })
                    Page.SALES -> SalesPage(products, onSell = { lines, invoice, paid, customer, phone, method ->
                        val saleId = db.checkout(lines, invoice, paid, customerName = customer, customerPhone = phone, method = method.code)
                        reload()
                        message = if (saleId > 0) "تم تسجيل البيع رقم $saleId" else "تعذر البيع: تحقق من المخزون والمبلغ المدفوع"
                    })
                    Page.PRODUCTS -> ProductsPage(products, onEdit = { selected = it; dialog = "product" })
                    Page.PURCHASES -> PurchasesPage(products, purchaseDraft, purchaseHistory, supplierNames,
                        linesOf = { db.purchaseLines(it) },
                        onNewProduct = { selected = null; dialog = "product" },
                        onSave = {
                            val id = db.addPurchaseInvoice(purchaseDraft.supplier, purchaseDraft.invoiceNo, purchaseDraft.lines.toList(),
                                purchaseDraft.paidAmount(), purchaseDraft.invoiceUri, purchaseDraft.deliveryUri, purchaseDraft.method.code)
                            reload()
                            if (id > 0) { purchaseDraft.clear(); message = "تم حفظ فاتورة المشتريات رقم $id وتحديث المخزون" }
                            else message = "تعذر حفظ الفاتورة: تحقق من اسم المورد والبنود والمبلغ المدفوع"
                        })
                    Page.MORE -> MorePage(onNavigate = { page = it })
                    Page.REPORTS -> ReportsPage(db, products, refresh)
                    Page.INVOICES -> InvoicesPage(invoices, linesOf = { db.saleLines(it) },
                        onReturn = { lineId, qty, method ->
                            val ok = db.returnLine(lineId, qty, method.code); reload()
                            message = if (ok) "تم تسجيل المرتجع وإرجاع البضاعة للمخزون" else "تعذر تسجيل المرتجع: تحقق من الكمية"
                        },
                        onCancel = { id, method ->
                            val ok = db.cancelSale(id, method.code); reload()
                            message = if (ok) "تم إلغاء الفاتورة وإرجاع البضاعة للمخزون" else "تعذر إلغاء الفاتورة"
                        })
                    Page.FINANCE -> FinancePage(summary, expenses, sales, onExpense = { dialog = "expense" }, onDebts = { page = Page.DEBTS }, onCash = { page = Page.CASHBOX })
                    Page.DEBTS -> DebtsPage(db, refresh, onChanged = { reload(); message = it })
                    Page.CASHBOX -> CashboxPage(db, refresh, onChanged = { reload(); message = it })
                    Page.BACKUP -> BackupPage(onBackup = { backupLauncher.launch("AL-AQSA-POS-backup.db") }, onRestore = { restoreLauncher.launch(arrayOf("application/octet-stream", "application/x-sqlite3", "*/*")) })
                }
            }
        }

        if (dialog == "product") ProductDialog(selected, products, onDismiss = { dialog = "" }) { p ->
            if (selected == null) db.addProduct(p.name, p.barcode, p.buy, p.sell, p.qty, p.unit, p.pack, p.packSell, p.category, p.minStock)
            else db.updateProduct(selected!!.id, p.name, p.barcode, p.buy, p.sell, p.qty, p.unit, p.pack, p.packSell, p.category, p.minStock)
            dialog = ""; reload()
        }
        if (dialog == "expense") ExpenseDialog(onDismiss = { dialog = "" }) { title, amount, note, method ->
            db.addExpense(title, amount, note, method.code); dialog = ""; reload()
            message = "تم تسجيل المصروف"
        }
        if (message.isNotBlank()) AlertDialog(
            onDismissRequest = { message = "" },
            confirmButton = { TextButton(onClick = { message = "" }) { Text("حسناً") } },
            text = { Text(message) }
        )
    }
}

@Composable
private fun HomePage(s: Summary, onNavigate: (Page) -> Unit) = Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
    Text("أهلاً بك في إدارة المكتبة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    Text("ملخص العمل اليومي", color = Color.Gray)
    Spacer(Modifier.height(12.dp))
    Card(colors = CardDefaults.cardColors(containerColor = Green), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text("مبيعات اليوم", color = Color.White)
            Text("${money(s.sales)} شيكل", color = Gold, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("الربح الإجمالي التقديري: ${money(s.sales - s.cost)} شيكل", color = Color.White)
        }
    }
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MetricCard("عدد الأصناف", s.products.toString(), Modifier.weight(1f))
        MetricCard("وحدات المخزون", s.stockUnits.toString(), Modifier.weight(1f))
    }
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MetricCard("مصروفات اليوم", money(s.expenses), Modifier.weight(1f))
        MetricCard("أصناف منخفضة", s.lowStock.toString(), Modifier.weight(1f))
    }
    Spacer(Modifier.height(16.dp))
    Text("الوصول السريع", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    listOf(Page.SALES, Page.PRODUCTS, Page.PURCHASES, Page.INVOICES, Page.FINANCE, Page.BACKUP).chunked(2).forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            row.forEach { p ->
                Button(onClick = { onNavigate(p) }, modifier = Modifier.weight(1f).height(54.dp)) {
                    Text(p.title)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
    Text("يعمل الكاشير محلياً دون إنترنت", color = Green, style = MaterialTheme.typography.labelMedium)
}

@Composable
private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Text(title, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Green)
        }
    }
}

@Composable
private fun ColumnScope.SalesPage(products: List<Product>, onSell: (List<Pair<Product, Pair<Int, Double>>>, Boolean, Double, String, String, PayMethod) -> Unit) {
    var query by remember { mutableStateOf("") }
    var showScanner by remember { mutableStateOf(false) }
    var cameraError by remember { mutableStateOf("") }
    var cart by remember { mutableStateOf(listOf<Pair<Product, Pair<Int, Double>>>()) }
    var invoiceChoice by remember { mutableStateOf(true) }
    var paidText by remember { mutableStateOf("0") }
    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var checkoutOpen by remember { mutableStateOf(false) }
    var payMethod by remember { mutableStateOf(PayMethod.CASH) }
    val context = LocalContext.current
    var hasCameraPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasCameraPermission = granted
        if (granted) showScanner = true else cameraError = "لم يتم منح إذن الكاميرا. فعّل الإذن من إعدادات التطبيق."
    }
    val cartTotal = cart.sumOf { it.second.first * it.second.second }
    Text("الكاشير والبيع السريع", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(),
        label = { Text("ابحث باسم المنتج أو أدخل الباركود") }, singleLine = true,
        leadingIcon = { Icon(Icons.Default.Search, null) })
    Spacer(Modifier.height(7.dp))
    Button(onClick = {
        if (hasCameraPermission) showScanner = true else permissionLauncher.launch(Manifest.permission.CAMERA)
    }, modifier = Modifier.fillMaxWidth().height(46.dp)) {
        Icon(Icons.Default.QrCodeScanner, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("مسح الباركود بالكاميرا")
    }
    Spacer(Modifier.height(8.dp))
    val filtered = products.filter { it.name.contains(query, true) || (query.isNotBlank() && it.barcode.contains(query, true)) }
    if (filtered.isEmpty()) Empty("لا توجد نتائج", "أضف المنتجات أو امسح باركود صنف مسجل.")
    else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        items(filtered, key = { it.id }) { p ->
            var qty by remember(p.id) { mutableStateOf("1") }
            var packMode by remember(p.id) { mutableStateOf(false) }
            val factor = if (packMode) p.packSize.coerceAtLeast(1) else 1
            val requested = (qty.toIntOrNull() ?: 0) * factor
            val price = if (packMode) p.packSellPrice / p.packSize.coerceAtLeast(1) else p.sellPrice
            val inCart = cart.firstOrNull { it.first.id == p.id }?.second?.first ?: 0
            Card {
                Column(Modifier.fillMaxWidth().padding(10.dp)) {
                    Text(p.name, fontWeight = FontWeight.Bold)
                    Text("المتوفر: ${p.quantity - inCart} قطعة • سعر القطعة: ${money(price)} شيكل")
                    if (p.packSize > 1) Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("طريقة البيع:")
                        FilterChip(selected = !packMode, onClick = { packMode = false }, label = { Text("قطعة") })
                        FilterChip(selected = packMode, onClick = { packMode = true }, label = { Text("عبوة × ${p.packSize}") })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(qty, { qty = it.filter(Char::isDigit) }, modifier = Modifier.weight(1f),
                            label = { Text(if (packMode) "عدد العبوات" else "الكمية") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = {
                            val old = cart.firstOrNull { it.first.id == p.id }
                            val newQty = (old?.second?.first ?: 0) + requested
                            cart = if (old == null) cart + (p to (requested to price))
                                else cart.map { if (it.first.id == p.id) p to (newQty to price) else it }
                            query = ""
                        }, enabled = requested > 0 && requested + inCart <= p.quantity) { Text("إضافة إلى السلة") }
                    }
                }
            }
        }
    }
    if (cart.isNotEmpty()) {
        Card(colors = CardDefaults.cardColors(containerColor = Cream), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("السلة (${cart.size} أصناف)", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${money(cartTotal)} ₪", color = Green, fontWeight = FontWeight.Bold)
                }
                cart.forEach { line ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${line.first.name} × ${line.second.first}", modifier = Modifier.weight(1f), maxLines = 1)
                        Text("${money(line.second.first * line.second.second)} ₪")
                        IconButton(onClick = { cart = cart.filterNot { it.first.id == line.first.id } }) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف من السلة", tint = Color.Red)
                        }
                    }
                }
                Button(onClick = { paidText = cartTotal.toString(); invoiceChoice = true; checkoutOpen = true }, modifier = Modifier.fillMaxWidth()) { Text("متابعة لإتمام البيع") }
            }
        }
    }
    if (checkoutOpen) AlertDialog(onDismissRequest = { checkoutOpen = false },
        title = { Text("تأكيد عملية البيع") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("عدد الأصناف: ${cart.size} • الإجمالي: ${money(cartTotal)} شيكل")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(selected = invoiceChoice, onClick = { invoiceChoice = true }, label = { Text("بفاتورة") })
                FilterChip(selected = !invoiceChoice, onClick = { invoiceChoice = false }, label = { Text("بدون فاتورة") })
            }
            if (invoiceChoice) {
                OutlinedTextField(customerName, { customerName = it }, label = { Text("اسم الزبون (اختياري)") }, singleLine = true)
                OutlinedTextField(customerPhone, { customerPhone = it }, label = { Text("رقم هاتف الزبون (اختياري)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
            }
            OutlinedTextField(paidText, { paidText = it }, label = { Text("المبلغ المدفوع") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            if ((paidText.toDoubleOrNull() ?: 0.0) > 0.0) PayMethodPicker(payMethod, { payMethod = it })
            Text("المبلغ غير المدفوع يُسجّل ديناً تلقائياً.", color = Green, style = MaterialTheme.typography.bodySmall)
        }},
        confirmButton = { TextButton(enabled = (paidText.toDoubleOrNull() ?: -1.0) in 0.0..cartTotal, onClick = {
            onSell(cart, invoiceChoice, paidText.toDoubleOrNull() ?: 0.0, customerName, customerPhone, payMethod)
            cart = emptyList(); customerName = ""; customerPhone = ""; checkoutOpen = false; paidText = "0"; payMethod = PayMethod.CASH
        }) { Text("تأكيد البيع") } },
        dismissButton = { TextButton(onClick = { checkoutOpen = false }) { Text("رجوع") } })
    if (cameraError.isNotBlank()) AlertDialog(onDismissRequest = { cameraError = "" },
        confirmButton = { TextButton(onClick = { cameraError = "" }) { Text("حسناً") } }, text = { Text(cameraError) })
    if (showScanner) BarcodeScannerDialog(onDismiss = { showScanner = false }, onBarcode = { code -> query = code; showScanner = false })
}

@OptIn(ExperimentalGetImage::class)
@Composable
private fun BarcodeScannerDialog(onDismiss: () -> Unit, onBarcode: (String) -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val executor = remember { Executors.newSingleThreadExecutor() }
    val handled = remember { AtomicBoolean(false) }
    var status by remember { mutableStateOf("وجّه الكاميرا نحو الباركود") }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var torchOn by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxWidth(0.96f).fillMaxHeight(0.78f), shape = MaterialTheme.shapes.large) {
            Column(Modifier.padding(12.dp)) {
                Text("ماسح الباركود", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(status, color = Green)
                Spacer(Modifier.height(8.dp))
                AndroidView(factory = { ctx ->
                    val previewView = PreviewView(ctx).apply {
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                        implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                    }
                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        try {
                            val cameraProvider = cameraProviderFuture.get()
                            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                            val scanner = BarcodeScanning.getClient()
                            val analysis = ImageAnalysis.Builder()
                                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                            analysis.setAnalyzer(executor) { imageProxy ->
                                val mediaImage = imageProxy.image
                                if (mediaImage == null || handled.get()) {
                                    imageProxy.close()
                                } else {
                                    val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                                    scanner.process(image)
                                        .addOnSuccessListener { barcodes ->
                                            val value = barcodes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
                                            if (value != null && handled.compareAndSet(false, true)) {
                                                previewView.post { onBarcode(value) }
                                            }
                                        }
                                        .addOnFailureListener { status = "تعذرت قراءة الرمز، قرّب الكاميرا وحاول مجدداً" }
                                        .addOnCompleteListener { imageProxy.close() }
                                }
                            }
                            cameraProvider.unbindAll()
                            camera = cameraProvider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                            Unit
                        } catch (e: Exception) {
                            status = "تعذر تشغيل الكاميرا: ${e.localizedMessage ?: "خطأ غير معروف"}"
                        }
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                }, modifier = Modifier.weight(1f).fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                if (camera?.cameraInfo?.hasFlashUnit() == true) {
                    Button(onClick = { torchOn = !torchOn; camera?.cameraControl?.enableTorch(torchOn) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(if (torchOn) Icons.Default.FlashOff else Icons.Default.FlashOn, null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (torchOn) "إيقاف الفلاش" else "تشغيل الفلاش (للإضاءة الضعيفة)")
                    }
                    Spacer(Modifier.height(6.dp))
                }
                OutlinedButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("إغلاق الماسح") }
            }
        }
    }
    DisposableEffect(lifecycleOwner) {
        onDispose {
            try { ProcessCameraProvider.getInstance(context).get().unbindAll() } catch (_: Exception) {}
            executor.shutdown()
        }
    }
}

@Composable
private fun ProductsPage(products: List<Product>, onEdit: (Product) -> Unit) {
    Text("إدارة المنتجات والمخزون", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    Text("اضغط على المنتج لتعديل بياناته", color = Color.Gray)
    Spacer(Modifier.height(8.dp))
    if (products.isEmpty()) Empty("المخزون فارغ", "اضغط زر + لإضافة أول منتج.")
    else LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        items(products, key = { it.id }) { p ->
            Card(onClick = { onEdit(p) }) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.Bold)
                        Text("شراء ${money(p.buyPrice)}  •  بيع ${money(p.sellPrice)} شيكل")
                        Text("المخزون: ${p.quantity} ${p.unitName}  •  حجم العبوة: ${p.packSize}",
                            style = MaterialTheme.typography.bodySmall)
                        Text("التصنيف: ${p.category}", style = MaterialTheme.typography.labelSmall)
                        if (p.barcode.isNotBlank()) Text("باركود: ${p.barcode}", style = MaterialTheme.typography.labelSmall)
                    }
                    Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = Green)
                }
            }
        }
    }
}

private class PurchaseDraft {
    var supplier by mutableStateOf("")
    var invoiceNo by mutableStateOf("")
    var paid by mutableStateOf("")
    var invoiceUri by mutableStateOf("")
    var deliveryUri by mutableStateOf("")
    var method by mutableStateOf(PayMethod.CASH)
    val lines = mutableStateListOf<PurchaseItem>()
    val total: Double get() = lines.sumOf { it.quantity * it.unitCost }
    fun paidAmount(): Double = paid.toDoubleOrNull() ?: 0.0
    fun clear() { supplier = ""; invoiceNo = ""; paid = ""; invoiceUri = ""; deliveryUri = ""; method = PayMethod.CASH; lines.clear() }
}

@Composable
private fun ColumnScope.PurchasesPage(
    products: List<Product>, draft: PurchaseDraft, history: List<PurchaseHeader>, suppliers: List<String>,
    linesOf: (Long) -> List<PurchaseItem>, onNewProduct: () -> Unit, onSave: () -> Unit
) {
    var tab by remember { mutableStateOf(0) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        if (tab == 0) Button(onClick = { tab = 0 }, modifier = Modifier.weight(1f)) { Text("فاتورة جديدة") }
        else OutlinedButton(onClick = { tab = 0 }, modifier = Modifier.weight(1f)) { Text("فاتورة جديدة") }
        if (tab == 1) Button(onClick = { tab = 1 }, modifier = Modifier.weight(1f)) { Text("سجل المشتريات") }
        else OutlinedButton(onClick = { tab = 1 }, modifier = Modifier.weight(1f)) { Text("سجل المشتريات") }
    }
    Spacer(Modifier.height(8.dp))
    if (tab == 0) NewPurchaseInvoice(products, draft, suppliers, onNewProduct, onSave)
    else PurchaseHistory(history, linesOf)
}

@Composable
private fun ColumnScope.NewPurchaseInvoice(
    products: List<Product>, draft: PurchaseDraft, suppliers: List<String>, onNewProduct: () -> Unit, onSave: () -> Unit
) {
    var selectedId by remember { mutableStateOf<Long?>(null) }
    var qty by remember { mutableStateOf("1") }
    var cost by remember { mutableStateOf("0") }
    var query by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    var showScanner by remember { mutableStateOf(false) }
    var cameraError by remember { mutableStateOf("") }
    val context = LocalContext.current
    fun keepAccess(uri: android.net.Uri) {
        try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
    }
    val invoicePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { keepAccess(it); draft.invoiceUri = it.toString() } }
    val deliveryPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { keepAccess(it); draft.deliveryUri = it.toString() } }
    var hasCameraPermission by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasCameraPermission = granted
        if (granted) showScanner = true else cameraError = "يرجى السماح باستخدام الكاميرا لمسح الباركود."
    }
    val selected = products.firstOrNull { it.id == selectedId }
    val matches = products.filter { it.name.contains(query, true) || (query.isNotBlank() && it.barcode.contains(query, true)) }
    val qtyInt = qty.toIntOrNull() ?: 0
    val costVal = cost.toDoubleOrNull() ?: -1.0
    val total = draft.total
    val paidOk = draft.paid.isBlank() || draft.paid.toDoubleOrNull() != null
    val paidVal = draft.paidAmount()
    val suggestions = suppliers.filter { draft.supplier.isBlank() || (it.contains(draft.supplier, true) && !it.equals(draft.supplier.trim(), true)) }.take(4)

    Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("فاتورة مشتريات جديدة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        OutlinedTextField(draft.supplier, { draft.supplier = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("اسم المورد (مطلوب)") })
        if (suggestions.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            suggestions.forEach { n -> OutlinedButton(onClick = { draft.supplier = n }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text(n, maxLines = 1) } }
        }
        OutlinedTextField(draft.invoiceNo, { draft.invoiceNo = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("رقم فاتورة المورد (اختياري)") })

        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("إضافة صنف للفاتورة", fontWeight = FontWeight.Bold, color = Green)
            OutlinedTextField(query, { query = it }, label = { Text("بحث باسم المنتج أو الباركود") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { if (hasCameraPermission) showScanner = true else permissionLauncher.launch(Manifest.permission.CAMERA) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.QrCodeScanner, null); Spacer(Modifier.width(5.dp)); Text("مسح الباركود")
                }
                OutlinedButton(onClick = onNewProduct, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("صنف جديد")
                }
            }
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(selected?.name ?: "اختر المنتج من القائمة") }
                DropdownMenu(expanded, { expanded = false }) {
                    matches.forEach { p -> DropdownMenuItem(text = { Text("${p.name} • ${p.barcode}") }, onClick = {
                        selectedId = p.id; cost = p.buyPrice.toString(); query = p.barcode; expanded = false
                    }) }
                }
            }
            if (query.isNotBlank() && matches.isEmpty()) Text("لا يوجد صنف بهذا الباركود. أضفه من زر (صنف جديد) ثم اخترْه.", color = Color(0xFF9A5A00), style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(qty, { qty = it.filter(Char::isDigit) }, label = { Text("الكمية بالقطعة") }, modifier = Modifier.weight(1f), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(cost, { cost = it }, label = { Text("سعر شراء القطعة") }, modifier = Modifier.weight(1f), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            }
            Button(
                onClick = {
                    val p = selected
                    if (p != null) {
                        draft.lines.add(PurchaseItem(p.id, p.name, qtyInt, costVal))
                        selectedId = null; query = ""; qty = "1"; cost = "0"
                    }
                },
                enabled = selected != null && qtyInt > 0 && costVal >= 0, modifier = Modifier.fillMaxWidth()
            ) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("إضافة للفاتورة") }
        } }

        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) {
            Text("بنود الفاتورة (${draft.lines.size})", fontWeight = FontWeight.Bold)
            if (draft.lines.isEmpty()) Text("لم تُضف أصناف بعد", color = Color.Gray)
            draft.lines.forEachIndexed { i, l ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(l.productName)
                        Text("${l.quantity} × ${money(l.unitCost)}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    }
                    Text("${money(l.quantity * l.unitCost)} ₪")
                    IconButton(onClick = { draft.lines.removeAt(i) }) { Icon(Icons.Default.Delete, contentDescription = "حذف البند", tint = MaterialTheme.colorScheme.error) }
                }
            }
            if (draft.lines.isNotEmpty()) {
                Divider(Modifier.padding(vertical = 4.dp))
                Text("إجمالي الفاتورة: ${money(total)} شيكل", fontWeight = FontWeight.Bold, color = Green)
            }
        } }

        OutlinedTextField(draft.paid, { draft.paid = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("المبلغ المدفوع للمورد الآن") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { draft.paid = money(total) }, enabled = total > 0, modifier = Modifier.weight(1f)) { Text("دفع كامل المبلغ") }
            OutlinedButton(onClick = { draft.paid = "" }, modifier = Modifier.weight(1f)) { Text("آجل بالكامل") }
        }
        if (paidVal > 0.0) PayMethodPicker(draft.method, { draft.method = it }, "طريقة الدفع للمورد")
        if (!paidOk || paidVal > total + 0.0001) Text("المبلغ المدفوع غير صحيح أو أكبر من إجمالي الفاتورة", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        else if (total > 0) Text("المتبقي ديناً للمورد: ${money(total - paidVal)} شيكل", color = Green, style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(onClick = { invoicePicker.launch(arrayOf("image/*", "application/pdf")) }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.ReceiptLong, null); Spacer(Modifier.width(4.dp)); Text(if (draft.invoiceUri.isNotBlank()) "تم إرفاق الفاتورة ✓" else "صورة فاتورة المورد")
            }
            OutlinedButton(onClick = { deliveryPicker.launch(arrayOf("image/*", "application/pdf")) }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.AttachFile, null); Spacer(Modifier.width(4.dp)); Text(if (draft.deliveryUri.isNotBlank()) "تم إرفاق السند ✓" else "سند التسليم")
            }
        }
        Button(
            onClick = onSave,
            enabled = draft.supplier.isNotBlank() && draft.lines.isNotEmpty() && paidOk && paidVal <= total + 0.0001,
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("حفظ فاتورة المشتريات وتحديث المخزون") }
        if (draft.lines.isNotEmpty() || draft.supplier.isNotBlank()) TextButton(onClick = { draft.clear() }, modifier = Modifier.fillMaxWidth()) { Text("تفريغ الفاتورة والبدء من جديد") }
        Spacer(Modifier.height(12.dp))
    }
    if (showScanner) BarcodeScannerDialog(onDismiss = { showScanner = false }, onBarcode = { code ->
        query = code; showScanner = false
        val found = products.firstOrNull { it.barcode == code }
        if (found != null) { selectedId = found.id; cost = found.buyPrice.toString() }
    })
    if (cameraError.isNotBlank()) AlertDialog(onDismissRequest = { cameraError = "" }, confirmButton = { TextButton(onClick = { cameraError = "" }) { Text("حسناً") } }, text = { Text(cameraError) })
}

@Composable
private fun ColumnScope.PurchaseHistory(history: List<PurchaseHeader>, linesOf: (Long) -> List<PurchaseItem>) {
    var openId by remember { mutableStateOf(-1L) }
    if (history.isEmpty()) {
        Empty("لا توجد فواتير مشتريات بعد", "ستظهر هنا بعد حفظ أول فاتورة")
        return
    }
    LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(history, key = { it.id }) { h ->
            val open = openId == h.id
            val due = h.total - h.paid
            Card(Modifier.fillMaxWidth().clickable { openId = if (open) -1L else h.id }) {
                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(h.supplier, fontWeight = FontWeight.Bold)
                        Text("${money(h.total)} ₪", fontWeight = FontWeight.Bold, color = Green)
                    }
                    Text("${localTime(h.createdAt)} • ${h.itemCount} صنف${if (h.supplierInvoiceNo.isNotBlank()) " • فاتورة المورد ${h.supplierInvoiceNo}" else ""}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    Text("المدفوع ${money(h.paid)} ₪" + (if (h.paid > 0.0001) " (${PayMethod.label(h.payMethod)})" else "") + (if (due > 0.0001) " • المتبقي ${money(due)} ₪" else ""))
                    if (open) {
                        Divider(Modifier.padding(vertical = 6.dp))
                        val lines = remember(h.id) { linesOf(h.id) }
                        if (lines.isEmpty()) Text("لا تتوفر تفاصيل البنود", color = Color.Gray)
                        lines.forEach { l ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("${l.productName}  ×${l.quantity}", modifier = Modifier.weight(1f))
                                Text("${money(l.quantity * l.unitCost)} ₪")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FinancePage(s: Summary, expenses: List<Expense>, sales: List<SaleLine>, onExpense: () -> Unit, onDebts: () -> Unit, onCash: () -> Unit) {
    Text("المصاريف والتقارير", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("ملخص اليوم", fontWeight = FontWeight.Bold)
            ReportLine("إجمالي المبيعات", s.sales)
            ReportLine("تكلفة البضاعة المباعة", s.cost)
            ReportLine("الربح قبل المصروفات", s.sales - s.cost)
            ReportLine("المصروفات", s.expenses)
            Divider()
            ReportLine("صافي الربح التقديري", s.sales - s.cost - s.expenses)
        }
    }
    Spacer(Modifier.height(10.dp))
    Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
        Text("ملخص الشهر الحالي", fontWeight = FontWeight.Bold)
        ReportLine("المبيعات الشهرية", s.monthSales)
        ReportLine("تكلفة البضاعة", s.monthCost)
        ReportLine("الربح قبل المصروفات", s.monthSales - s.monthCost)
        ReportLine("المصروفات الشهرية", s.monthExpenses)
        ReportLine("صافي الربح الشهري", s.monthSales - s.monthCost - s.monthExpenses)
    } }
    Spacer(Modifier.height(10.dp))
    Button(onClick = onExpense, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("إضافة مصروف")
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = onDebts, modifier = Modifier.weight(1f)) { Text("إدارة الديون") }
        OutlinedButton(onClick = onCash, modifier = Modifier.weight(1f)) { Text("الصندوق") }
    }
    Spacer(Modifier.height(12.dp))
    Text("آخر المصروفات", fontWeight = FontWeight.Bold)
    if (expenses.isEmpty()) Text("لا توجد مصروفات مسجلة", color = Color.Gray)
    else LazyColumn(Modifier.heightIn(max = 150.dp)) {
        items(expenses) { e -> ListItem(headlineContent = { Text(e.title) },
            supportingContent = { Text(e.createdAt) }, trailingContent = { Text("${money(e.amount)} ₪") }) }
    }
    Text("آخر المبيعات", fontWeight = FontWeight.Bold)
    if (sales.isEmpty()) Text("لا توجد مبيعات مسجلة", color = Color.Gray)
    else LazyColumn(Modifier.heightIn(max = 190.dp)) {
        items(sales) { line -> ListItem(
            headlineContent = { Text(line.productName) },
            supportingContent = { Text("${line.quantity} قطعة • ${line.createdAt}") },
            trailingContent = { Text("${money(line.quantity * line.unitPrice)} ₪") }
        ) }
    }
}

private val DebtRed = Color(0xFFB3261E)

@Composable
private fun DebtSummaryTile(title: String, amount: Double, count: Int, tint: Color, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = tint.copy(alpha = 0.10f))) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = Color.DarkGray)
            Text("${money(amount)} ₪", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = tint)
            Text("$count حساب", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
        }
    }
}

@Composable
private fun DebtsPage(db: StoreDb, refresh: Int, onChanged: (String) -> Unit) {
    var type by remember { mutableStateOf("customer") }
    var query by remember { mutableStateOf("") }
    var byAmount by remember { mutableStateOf(true) }
    var statement by remember { mutableStateOf<DebtParty?>(null) }
    var addOpen by remember { mutableStateOf(false) }
    val all = remember(refresh) { db.balances() }
    val parties = remember(refresh, type) { db.debtParties(type) }
    val customers = all.filter { it.partyType == "customer" }
    val suppliers = all.filter { it.partyType == "supplier" }
    val tint = if (type == "customer") Green else DebtRed
    val shown = parties.filter { query.isBlank() || it.name.contains(query, true) }
        .let { l -> if (byAmount) l.sortedByDescending { it.balance } else l.sortedBy { it.name } }
    Column(Modifier.fillMaxSize()) {
        Text("الديون والذمم", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            DebtSummaryTile("مستحق لنا عند الزبائن", customers.sumOf { it.balance }, customers.size, Green, Modifier.weight(1f))
            DebtSummaryTile("مستحق علينا للموردين", suppliers.sumOf { it.balance }, suppliers.size, DebtRed, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            if (type == "customer") Button(onClick = { type = "customer" }, modifier = Modifier.weight(1f)) { Text("الزبائن") }
            else OutlinedButton(onClick = { type = "customer" }, modifier = Modifier.weight(1f)) { Text("الزبائن") }
            if (type == "supplier") Button(onClick = { type = "supplier" }, modifier = Modifier.weight(1f)) { Text("الموردون") }
            else OutlinedButton(onClick = { type = "supplier" }, modifier = Modifier.weight(1f)) { Text("الموردون") }
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(query, { query = it }, modifier = Modifier.weight(1f), singleLine = true,
                label = { Text("بحث بالاسم") }, leadingIcon = { Icon(Icons.Default.Search, null) })
            Spacer(Modifier.width(8.dp))
            OutlinedButton(onClick = { byAmount = !byAmount }) { Text(if (byAmount) "الأعلى مبلغاً" else "حسب الاسم") }
        }
        Spacer(Modifier.height(6.dp))
        if (shown.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                Empty(if (query.isBlank()) "لا توجد ديون مستحقة" else "لا توجد نتائج", if (query.isBlank()) "ستظهر هنا الحسابات المفتوحة تلقائياً" else "جرّب اسماً آخر")
            }
        } else LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown, key = { it.type + "|" + it.name }) { party ->
                Card(Modifier.fillMaxWidth().clickable { statement = party }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(tint.copy(alpha = 0.15f), CircleShape), contentAlignment = Alignment.Center) {
                            Text(party.name.take(1), fontWeight = FontWeight.Bold, color = tint)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(party.name, fontWeight = FontWeight.Bold)
                            if (party.lastDate.isNotBlank()) Text("آخر حركة: ${localTime(party.lastDate).take(10)}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                            if (party.phone.isNotBlank()) Text(party.phone, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("${money(party.balance)} ₪", fontWeight = FontWeight.Bold, color = tint)
                            Text(if (type == "customer") "مستحق لنا" else "مستحق علينا", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Button(onClick = { addOpen = true }, modifier = Modifier.fillMaxWidth().height(50.dp)) {
            Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text(if (type == "customer") "تسجيل دين على زبون" else "تسجيل مستحق لمورد")
        }
    }
    statement?.let { party -> PartyStatementDialog(db, party, refresh, onDismiss = { statement = null }, onChanged = onChanged) }
    if (addOpen) DebtAddDialog(type, null, onDismiss = { addOpen = false }) { name, amount, note ->
        db.addDebt(type, name, amount, note); addOpen = false; onChanged("تم تسجيل الدين على $name")
    }
}

@Composable
private fun PartyStatementDialog(db: StoreDb, party: DebtParty, refresh: Int, onDismiss: () -> Unit, onChanged: (String) -> Unit) {
    val context = LocalContext.current
    val rows = remember(party.name, refresh) { db.ledger(party.type, party.name) }
    val balance = remember(party.name, refresh) { db.balance(party.type, party.name) }
    var payOpen by remember { mutableStateOf(false) }
    var addOpen by remember { mutableStateOf(false) }
    val isCustomer = party.type == "customer"
    val tint = if (isCustomer) Green else DebtRed
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth(0.96f).fillMaxHeight(0.92f), shape = MaterialTheme.shapes.large) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(party.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(if (isCustomer) "كشف حساب زبون" else "كشف حساب مورد", style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                        if (party.phone.isNotBlank()) Text(party.phone, style = MaterialTheme.typography.labelMedium)
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "إغلاق") }
                }
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = tint)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Text(if (isCustomer) "الرصيد المستحق لنا" else "الرصيد المستحق علينا", color = Color.White)
                        Text("${money(balance)} شيكل", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { payOpen = true }, enabled = balance > 0.0001, modifier = Modifier.weight(1f)) { Text(if (isCustomer) "تحصيل دفعة" else "سداد دفعة") }
                    OutlinedButton(onClick = { addOpen = true }, modifier = Modifier.weight(1f)) { Text("إضافة دين") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { InvoiceShare.shareStatement(context, party.type, party.name, rows, balance) }, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Share, null); Spacer(Modifier.width(4.dp)); Text("مشاركة الكشف")
                    }
                    if (party.phone.isNotBlank()) OutlinedButton(
                        onClick = { context.startActivity(android.content.Intent(android.content.Intent.ACTION_DIAL, Uri.parse("tel:${party.phone}"))) },
                        modifier = Modifier.weight(1f)
                    ) { Icon(Icons.Default.Phone, null); Spacer(Modifier.width(4.dp)); Text("اتصال") }
                }
                Spacer(Modifier.height(8.dp))
                Text("سجل الحركات (الأحدث أولاً)", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                if (rows.isEmpty()) Empty("لا توجد حركات", "")
                else LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(rows.reversed()) { r -> LedgerItem(r) }
                }
            }
        }
    }
    if (payOpen) DebtPaymentDialog(party.type, party.name, balance, onDismiss = { payOpen = false }) { amount, note, method ->
        val ok = db.payDebt(party.type, party.name, amount, note, method.code)
        payOpen = false
        onChanged(if (ok) "تم تسجيل الدفعة (${method.label})" else "تعذر تسجيل الدفعة؛ تحقق من المبلغ والرصيد")
    }
    if (addOpen) DebtAddDialog(party.type, party.name, onDismiss = { addOpen = false }) { name, amount, note ->
        db.addDebt(party.type, name, amount, note); addOpen = false; onChanged("تم تسجيل الدين")
    }
}

@Composable
private fun LedgerItem(r: LedgerRow) {
    val color = if (r.isDebit) DebtRed else Green
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(ledgerTitle(r), fontWeight = FontWeight.SemiBold)
                Text(localTime(r.date), style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                if (r.note.isNotBlank()) Text(r.note, style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                if (!r.isDebit && r.method.isNotBlank()) Text("طريقة الدفع: ${PayMethod.label(r.method)}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text((if (r.isDebit) "+" else "−") + money(r.amount), color = color, fontWeight = FontWeight.Bold)
                Text("الرصيد ${money(r.running)}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            }
        }
    }
}

@Composable
private fun DebtPaymentDialog(type: String, name: String, balance: Double, onDismiss: () -> Unit, onConfirm: (Double, String, PayMethod) -> Unit) {
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var method by remember { mutableStateOf(PayMethod.CASH) }
    val value = amount.toDoubleOrNull() ?: 0.0
    val valid = value > 0 && value <= balance + 0.0001
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (type == "customer") "تحصيل دفعة من $name" else "سداد دفعة للمورد $name") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("الرصيد الحالي: ${money(balance)} شيكل", fontWeight = FontWeight.Bold)
            OutlinedTextField(amount, { amount = it }, singleLine = true, label = { Text("المبلغ بالشيكل") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), isError = amount.isNotBlank() && !valid)
            OutlinedButton(onClick = { amount = money(balance) }) { Text("سداد كامل الرصيد") }
            if (amount.isNotBlank() && !valid) Text("المبلغ غير صحيح أو أكبر من الرصيد", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            else if (valid) Text("المتبقي بعد الدفعة: ${money(balance - value)} شيكل", color = Green, style = MaterialTheme.typography.bodySmall)
            PayMethodPicker(method, { method = it })
            OutlinedTextField(note, { note = it }, singleLine = true, label = { Text("ملاحظة (اختياري)") })
        } },
        confirmButton = { TextButton(enabled = valid, onClick = { onConfirm(value, note, method) }) { Text("حفظ الدفعة") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun DebtAddDialog(type: String, presetName: String?, onDismiss: () -> Unit, onConfirm: (String, Double, String) -> Unit) {
    var name by remember { mutableStateOf(presetName ?: "") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val value = amount.toDoubleOrNull() ?: 0.0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (type == "customer") "تسجيل دين على زبون" else "تسجيل مستحق لمورد") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, enabled = presetName == null, singleLine = true,
                label = { Text(if (type == "customer") "اسم الزبون" else "اسم المورد") })
            OutlinedTextField(amount, { amount = it }, singleLine = true, label = { Text("المبلغ بالشيكل") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
            OutlinedTextField(note, { note = it }, singleLine = true, label = { Text("ملاحظة (اختياري)") })
        } },
        confirmButton = { TextButton(enabled = name.isNotBlank() && value > 0, onClick = { onConfirm(name.trim(), value, note) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun CashboxPage(db: StoreDb, refresh: Int, onChanged: (String) -> Unit) {
    var opening by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("إيداع") }
    var method by remember { mutableStateOf(PayMethod.CASH) }
    var fromM by remember { mutableStateOf(PayMethod.CASH) }
    var toM by remember { mutableStateOf(PayMethod.BOP) }
    var transferAmount by remember { mutableStateOf("") }
    val balances = remember(refresh) { db.methodBalances() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("الصندوق والمحافظ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = Green)) { Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text("إجمالي السيولة (الصندوق + المحافظ + البنك)", color = Color.White)
            Text("${money(balances.sumOf { it.balance })} شيكل", color = Gold, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        } }
        balances.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                row.forEach { b ->
                    Card(Modifier.weight(1f)) { Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(if (b.method == PayMethod.CASH) "الصندوق (كاش)" else b.method.label, color = Color.Gray, style = MaterialTheme.typography.labelMedium)
                        Text("${money(b.balance)} ₪", fontWeight = FontWeight.Bold, color = Green, style = MaterialTheme.typography.titleLarge)
                        Text("داخل ${money(b.cashIn)} • خارج ${money(b.cashOut)}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    } }
                }
            }
        }
        Divider()
        Text("الرصيد الافتتاحي للصندوق النقدي", fontWeight = FontWeight.Bold)
        OutlinedTextField(opening, { opening = it }, label = { Text("رصيد افتتاحي بالكاش (شيكل)") }, modifier = Modifier.fillMaxWidth(), singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        Button(onClick = { db.setOpeningCash(opening.toDoubleOrNull() ?: 0.0); onChanged("تم حفظ الرصيد الافتتاحي") },
            modifier = Modifier.fillMaxWidth(), enabled = (opening.toDoubleOrNull() ?: -1.0) >= 0) { Text("حفظ الرصيد الافتتاحي") }
        Divider()
        Text("حركة يدوية", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("إيداع", "سحب شخصي").forEach { k -> FilterChip(selected = kind == k, onClick = { kind = k }, label = { Text(k) }) }
        }
        PayMethodPicker(method, { method = it }, "الحساب")
        OutlinedTextField(amount, { amount = it }, label = { Text("المبلغ") }, modifier = Modifier.fillMaxWidth(), singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        OutlinedTextField(note, { note = it }, label = { Text("البيان") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { db.addCashMove(kind, amount.toDoubleOrNull() ?: 0.0, note, method.code); onChanged("تم تسجيل الحركة (${method.label})"); amount = ""; note = "" },
            enabled = (amount.toDoubleOrNull() ?: 0.0) > 0, modifier = Modifier.fillMaxWidth()) { Text("تسجيل الحركة") }
        Divider()
        Text("تحويل بين الحسابات (مثلاً إيداع كاش في البنك)", fontWeight = FontWeight.Bold)
        PayMethodPicker(fromM, { fromM = it }, "من")
        PayMethodPicker(toM, { toM = it }, "إلى")
        OutlinedTextField(transferAmount, { transferAmount = it }, label = { Text("مبلغ التحويل") }, modifier = Modifier.fillMaxWidth(), singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        Button(onClick = {
            val ok = db.transferBetween(fromM, toM, transferAmount.toDoubleOrNull() ?: 0.0)
            onChanged(if (ok) "تم التحويل من ${fromM.label} إلى ${toM.label}" else "اختر حسابين مختلفين وأدخل مبلغاً صحيحاً")
            if (ok) transferAmount = ""
        }, enabled = fromM != toM && (transferAmount.toDoubleOrNull() ?: 0.0) > 0, modifier = Modifier.fillMaxWidth()) { Text("تنفيذ التحويل") }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun BackupPage(onBackup: () -> Unit, onRestore: () -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("النسخ الاحتياطي والاستعادة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("حافظ على بيانات المكتبة", fontWeight = FontWeight.Bold)
            Text("أنشئ نسخة من قاعدة البيانات تشمل الأصناف والمخزون والمبيعات والمشتريات والديون والصندوق. احفظها في مكان آمن أو على ذاكرة خارجية.", color = Color.Gray)
            Button(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Backup, null); Spacer(Modifier.width(6.dp)); Text("إنشاء نسخة احتياطية") }
        } }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("استعادة نسخة سابقة", fontWeight = FontWeight.Bold)
            Text("تنبيه: الاستعادة تستبدل بيانات التطبيق الحالية بالبيانات الموجودة داخل ملف النسخة. اختر ملف قاعدة بيانات AL-AQSA POS موثوقاً.", color = Color(0xFF9A5B00))
            OutlinedButton(onClick = onRestore, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Restore, null); Spacer(Modifier.width(6.dp)); Text("اختيار ملف للاستعادة") }
        } }
        Text("مهم: احتفظ بنسخة احتياطية دورية، خصوصاً قبل تحديث التطبيق أو تغيير الهاتف.", color = Green)
    }
}

@Composable
private fun ReportLine(label: String, amount: Double) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label); Text("${money(amount)} شيكل", fontWeight = FontWeight.SemiBold)
    }
}

private data class ProductInput(
    val name: String, val barcode: String, val buy: Double,
    val sell: Double, val qty: Int, val unit: String, val pack: Int,
    val packSell: Double, val category: String, val minStock: Int = 3
)

@Composable
private fun ProductDialog(old: Product?, existing: List<Product>, onDismiss: () -> Unit, onSave: (ProductInput) -> Unit) {
    var name by remember { mutableStateOf(old?.name ?: "") }
    var barcode by remember { mutableStateOf(old?.barcode ?: "") }
    val context = LocalContext.current
    var showScanner by remember { mutableStateOf(false) }
    var cameraError by remember { mutableStateOf("") }
    var hasCameraPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasCameraPermission = granted
        if (granted) { cameraError = ""; showScanner = true } else cameraError = "لم يتم منح إذن الكاميرا. فعّل الإذن من إعدادات التطبيق."
    }
    var category by remember { mutableStateOf(old?.category ?: "عام") }
    var minStock by remember { mutableStateOf((old?.minStock ?: 3).toString()) }
    val duplicate = if (barcode.isBlank()) null else existing.firstOrNull { it.barcode.trim() == barcode.trim() && it.id != old?.id }
    var unit by remember { mutableStateOf(old?.unitName ?: "قطعة") }
    var pack by remember { mutableStateOf(old?.packSize?.toString() ?: "12") }
    var buyPack by remember { mutableStateOf(old?.let { money(it.buyPrice * it.packSize) } ?: "0") }
    var sell by remember { mutableStateOf(old?.sellPrice?.toString() ?: "0") }
    var sellPack by remember { mutableStateOf(old?.packSellPrice?.toString() ?: "0") }
    val packCountInitial = old?.let { it.quantity / it.packSize.coerceAtLeast(1) } ?: 0
    val looseInitial = old?.let { it.quantity % it.packSize.coerceAtLeast(1) } ?: 0
    var packsInStock by remember { mutableStateOf(packCountInitial.toString()) }
    var looseStock by remember { mutableStateOf(looseInitial.toString()) }
    val packSize = (pack.toIntOrNull() ?: 1).coerceAtLeast(1)
    val buyPackValue = buyPack.toDoubleOrNull() ?: 0.0
    val pieceCost = buyPackValue / packSize
    val totalPieces = (packsInStock.toIntOrNull() ?: 0) * packSize + (looseStock.toIntOrNull() ?: 0)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (old == null) "إضافة منتج" else "تعديل المنتج") },
        text = {
            Column(
                Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Text("1. بيانات المنتج", fontWeight = FontWeight.Bold, color = Green)
                OutlinedTextField(name, { name = it }, label = { Text("اسم المنتج") }, singleLine = true)
                OutlinedTextField(
                    barcode, { barcode = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("الباركود (اكتبه أو امسحه بالكاميرا)") }, singleLine = true,
                    trailingIcon = {
                        IconButton(onClick = {
                            if (hasCameraPermission) showScanner = true else permissionLauncher.launch(Manifest.permission.CAMERA)
                        }) { Icon(Icons.Default.QrCodeScanner, contentDescription = "مسح الباركود بالكاميرا") }
                    }
                )
                if (cameraError.isNotBlank()) Text(cameraError, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelMedium)
                if (duplicate != null) Text("هذا الباركود مسجل مسبقاً للمنتج: ${duplicate.name}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelMedium)
                OutlinedTextField(category, { category = it }, label = { Text("تصنيف المنتج (مثلاً: دفاتر، أقلام، أدوات مكتبية)") }, singleLine = true)
                Text("2. بيانات العبوة والشراء", fontWeight = FontWeight.Bold, color = Green)
                OutlinedTextField(unit, { unit = it }, label = { Text("اسم القطعة (قلم/دفتر...)") }, singleLine = true)
                OutlinedTextField(pack, { pack = it.filter(Char::isDigit) }, label = { Text("عدد القطع داخل العبوة/الدستة") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(buyPack, { buyPack = it }, label = { Text("سعر شراء العبوة كاملة (شيكل)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                Text("تكلفة القطعة تلقائياً: ${money(pieceCost)} شيكل", color = Green, fontWeight = FontWeight.SemiBold)
                Text("3. أسعار البيع", fontWeight = FontWeight.Bold, color = Green)
                OutlinedTextField(sell, { sell = it }, label = { Text("سعر بيع القطعة (شيكل)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(sellPack, { sellPack = it }, label = { Text("سعر بيع العبوة كاملة (شيكل)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                Text("4. المخزون الحالي", fontWeight = FontWeight.Bold, color = Green)
                OutlinedTextField(packsInStock, { packsInStock = it.filter(Char::isDigit) }, label = { Text("عدد العبوات الموجودة") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(looseStock, { looseStock = it.filter(Char::isDigit) }, label = { Text("قطع مفردة إضافية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(minStock, { minStock = it.filter(Char::isDigit) }, label = { Text("حد التنبيه عند نقص المخزون (قطعة)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                Text("إجمالي المخزون: $totalPieces قطعة", color = Green, fontWeight = FontWeight.Bold)
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank() && packSize > 0 && duplicate == null, onClick = {
                val unitBuy = pieceCost
                onSave(ProductInput(
                    name, barcode, unitBuy, sell.toDoubleOrNull() ?: 0.0,
                    totalPieces, unit.ifBlank { "قطعة" }, packSize,
                    sellPack.toDoubleOrNull() ?: ((sell.toDoubleOrNull() ?: 0.0) * packSize), category.ifBlank { "عام" },
                    minStock.toIntOrNull() ?: 3
                ))
            }) { Text("حفظ المنتج") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
    if (showScanner) BarcodeScannerDialog(
        onDismiss = { showScanner = false },
        onBarcode = { code -> barcode = code; showScanner = false }
    )
}

@Composable
private fun ExpenseDialog(onDismiss: () -> Unit, onSave: (String, Double, String, PayMethod) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var method by remember { mutableStateOf(PayMethod.CASH) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة مصروف") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("اسم المصروف") }, singleLine = true)
            OutlinedTextField(amount, { amount = it }, label = { Text("المبلغ بالشيكل") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            PayMethodPicker(method, { method = it }, "طريقة الدفع")
            OutlinedTextField(note, { note = it }, label = { Text("ملاحظات (اختياري)") })
        }},
        confirmButton = { TextButton(enabled = title.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0) > 0,
            onClick = { onSave(title, amount.toDoubleOrNull() ?: 0.0, note, method) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}


@Composable
private fun MorePage(onNavigate: (Page) -> Unit) = Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
    Text("المزيد", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
    listOf(Page.INVOICES, Page.REPORTS, Page.FINANCE, Page.DEBTS, Page.CASHBOX, Page.BACKUP).chunked(2).forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            row.forEach { p -> Button(onClick = { onNavigate(p) }, modifier = Modifier.weight(1f).height(56.dp)) { Text(p.title) } }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun ColumnScope.InvoicesPage(
    invoices: List<SaleHeader>, linesOf: (Long) -> List<InvoiceLine>,
    onReturn: (Long, Int, PayMethod) -> Unit, onCancel: (Long, PayMethod) -> Unit
) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var openId by remember { mutableStateOf(-1L) }
    var returnTarget by remember { mutableStateOf<InvoiceLine?>(null) }
    var returnQtyText by remember { mutableStateOf("1") }
    var cancelTarget by remember { mutableStateOf<SaleHeader?>(null) }
    var refundMethod by remember { mutableStateOf(PayMethod.CASH) }
    Text("سجل الفواتير", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
    OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
        label = { Text("بحث برقم الفاتورة أو اسم/هاتف الزبون") }, leadingIcon = { Icon(Icons.Default.Search, null) })
    Spacer(Modifier.height(6.dp))
    val shown = invoices.filter {
        query.isBlank() || it.invoiceNo.contains(query, true) || it.customerName.contains(query, true) || it.customerPhone.contains(query)
    }
    if (shown.isEmpty()) {
        Empty("لا توجد فواتير", "ستظهر هنا كل عملية بيع بعد تسجيلها")
    } else LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(shown, key = { it.id }) { h ->
            val net = (h.total - h.returnedValue).coerceAtLeast(0.0)
            val due = net - h.paid
            val open = openId == h.id
            Card(Modifier.fillMaxWidth().clickable { openId = if (open) -1L else h.id }) {
                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(if (h.hasInvoice) "فاتورة ${h.invoiceNo}" else "بيع سريع #${h.id}", fontWeight = FontWeight.Bold)
                        Text("${money(h.total)} ₪", fontWeight = FontWeight.Bold, color = Green)
                    }
                    Text(localTime(h.createdAt), style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    if (h.customerName.isNotBlank()) Text("الزبون: ${h.customerName}${if (h.customerPhone.isNotBlank()) " • ${h.customerPhone}" else ""}")
                    if (h.returnedValue > 0.0001) Text("مرتجع ${money(h.returnedValue)} ₪ • الصافي ${money(net)} ₪", color = Color(0xFFB26A00))
                    if (h.paid > 0.0001) Text("طريقة الدفع: ${PayMethod.label(h.payMethod)}", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    if (due > 0.0001) Text("المدفوع ${money(h.paid)} • المتبقي دين ${money(due)} ₪", color = MaterialTheme.colorScheme.error)
                    if (open) {
                        Divider(Modifier.padding(vertical = 6.dp))
                        val lines = remember(h.id, h.returnedValue) { linesOf(h.id) }
                        if (lines.isEmpty()) Text("لا تتوفر تفاصيل البنود لهذه الفاتورة (بيع قديم)", color = Color.Gray)
                        lines.forEach { l ->
                            val remaining = l.quantity - l.returnedQty
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("${l.productName}  ×${l.quantity}")
                                    if (l.returnedQty > 0) Text("مرتجع ${l.returnedQty}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                                }
                                Text("${money(l.quantity * l.unitPrice)} ₪")
                                if (remaining > 0) TextButton(onClick = { returnTarget = l; returnQtyText = "1"; refundMethod = PayMethod.of(h.payMethod) }) { Text("إرجاع") }
                            }
                        }
                        if (h.discount > 0.0001) Text("الخصم: ${money(h.discount)} ₪", color = Color.Gray)
                        Spacer(Modifier.height(6.dp))
                        if (lines.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick = { InvoiceShare.shareText(context, h, lines) }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.Share, null); Spacer(Modifier.width(4.dp)); Text("نص / واتساب")
                            }
                            OutlinedButton(onClick = { InvoiceShare.sharePdf(context, h, lines) }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(4.dp)); Text("PDF / طباعة")
                            }
                        }
                        if (lines.any { it.quantity > it.returnedQty }) TextButton(
                            onClick = { cancelTarget = h; refundMethod = PayMethod.of(h.payMethod) },
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) { Text("إلغاء الفاتورة بالكامل") }
                    }
                }
            }
        }
    }
    returnTarget?.let { l ->
        val remaining = l.quantity - l.returnedQty
        AlertDialog(
            onDismissRequest = { returnTarget = null },
            title = { Text("إرجاع ${l.productName}") },
            text = { Column {
                Text("المتاح للإرجاع: $remaining قطعة")
                OutlinedTextField(returnQtyText, { returnQtyText = it.filter(Char::isDigit) }, label = { Text("الكمية المرجعة") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                PayMethodPicker(refundMethod, { refundMethod = it }, "طريقة رد المبلغ (إن كان الزبون قد دفع)")
            } },
            confirmButton = {
                val q = returnQtyText.toIntOrNull() ?: 0
                TextButton(enabled = q in 1..remaining, onClick = { onReturn(l.id, q, refundMethod); returnTarget = null }) { Text("تأكيد الإرجاع") }
            },
            dismissButton = { TextButton(onClick = { returnTarget = null }) { Text("إلغاء") } }
        )
    }
    cancelTarget?.let { h ->
        AlertDialog(
            onDismissRequest = { cancelTarget = null },
            title = { Text("إلغاء الفاتورة") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("ستعود كل البضاعة المتبقية إلى المخزون، ويُعكس المبلغ المدفوع والدين المسجل. هل أنت متأكد؟")
                PayMethodPicker(refundMethod, { refundMethod = it }, "طريقة رد المبلغ (إن كان الزبون قد دفع)")
            } },
            confirmButton = { TextButton(onClick = { onCancel(h.id, refundMethod); cancelTarget = null }) { Text("نعم، ألغِ الفاتورة") } },
            dismissButton = { TextButton(onClick = { cancelTarget = null }) { Text("تراجع") } }
        )
    }
}

@Composable
private fun ColumnScope.ReportsPage(db: StoreDb, products: List<Product>, refresh: Int) {
    var preset by remember { mutableStateOf("اليوم") }
    var customFrom by remember { mutableStateOf("") }
    var customTo by remember { mutableStateOf("") }
    val presets = listOf("اليوم", "أمس", "آخر 7 أيام", "هذا الشهر", "الشهر الماضي", "فترة مخصصة")
    val range: Pair<String, String>? = remember(preset, customFrom, customTo, refresh) {
        when (preset) {
            "اليوم" -> db.dateOf("+0 day").let { it to it }
            "أمس" -> db.dateOf("-1 day").let { it to it }
            "آخر 7 أيام" -> db.dateOf("-6 day") to db.dateOf("+0 day")
            "هذا الشهر" -> db.dateOf("start of month") to db.dateOf("+0 day")
            "الشهر الماضي" -> db.dateOf("start of month", "-1 month") to db.dateOf("start of month", "-1 day")
            else -> {
                val re = Regex("""\d{4}-\d{2}-\d{2}""")
                if (re.matches(customFrom) && re.matches(customTo) && customFrom <= customTo) customFrom to customTo else null
            }
        }
    }
    val report = remember(range, refresh) { range?.let { db.periodReport(it.first, it.second) } }
    val slow = remember(refresh) { db.slowProducts(60) }
    val low = products.filter { it.quantity <= it.minStock }.sortedBy { it.quantity }

    Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
        Text("تقارير الفترات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        presets.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                row.forEach { name ->
                    if (name == preset) Button(onClick = { preset = name }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) { Text(name, maxLines = 1, style = MaterialTheme.typography.labelMedium) }
                    else OutlinedButton(onClick = { preset = name }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp)) { Text(name, maxLines = 1, style = MaterialTheme.typography.labelMedium) }
                }
            }
        }
        if (preset == "فترة مخصصة") {
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(customFrom, { customFrom = it.take(10) }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("من (2026-11-01)") })
                OutlinedTextField(customTo, { customTo = it.take(10) }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("إلى (2026-11-30)") })
            }
            if (range == null) Text("أدخل التاريخين بصيغة yyyy-MM-dd والبداية قبل النهاية", color = Color.Gray, style = MaterialTheme.typography.labelMedium)
        }
        Spacer(Modifier.height(8.dp))
        if (range != null && report != null) {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                Text("من ${range.first} إلى ${range.second}", style = MaterialTheme.typography.labelMedium, color = Color.Gray)
                ReportLine("صافي المبيعات (بعد المرتجعات)", report.sales)
                ReportLine("منها مرتجعات", report.returns)
                ReportLine("تكلفة البضاعة المباعة", report.cost)
                ReportLine("الربح قبل المصروفات", report.sales - report.cost)
                ReportLine("المصروفات", report.expenses)
                Divider()
                ReportLine("صافي الربح التقديري", report.sales - report.cost - report.expenses)
                Text("عدد الفواتير: ${report.invoices}", color = Color.Gray)
            } }
            Spacer(Modifier.height(8.dp))
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                Text("الأكثر مبيعاً في الفترة", fontWeight = FontWeight.Bold)
                if (report.top.isEmpty()) Text("لا توجد مبيعات في هذه الفترة", color = Color.Gray)
                report.top.forEachIndexed { i, (name, qty) -> Text("${i + 1}. $name — $qty قطعة") }
            } }
        }
        Spacer(Modifier.height(8.dp))
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
            Text("بضاعة قاربت على النفاد (حسب حد كل منتج)", fontWeight = FontWeight.Bold)
            if (low.isEmpty()) Text("لا توجد", color = Color.Gray)
            low.take(30).forEach { Text("${it.name} — المتبقي ${it.quantity}") }
        } }
        Spacer(Modifier.height(8.dp))
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
            Text("بضاعة راكدة (لم تُبع منذ 60 يوماً)", fontWeight = FontWeight.Bold)
            if (slow.isEmpty()) Text("لا توجد", color = Color.Gray)
            slow.forEach { (name, qty) -> Text("$name — $qty قطعة في المخزون") }
        } }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun Empty(title: String, subtitle: String) {
    Box(Modifier.fillMaxWidth().padding(25.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Color.Gray)
        }
    }
}

@Composable
private fun PayMethodPicker(selected: PayMethod, onSelect: (PayMethod) -> Unit, label: String = "طريقة الدفع") {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = Color.Gray)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            PayMethod.values().forEach { m -> FilterChip(selected = selected == m, onClick = { onSelect(m) }, label = { Text(m.label) }) }
        }
    }
}

private fun money(value: Double): String = String.format(Locale.US, "%.2f", value)
