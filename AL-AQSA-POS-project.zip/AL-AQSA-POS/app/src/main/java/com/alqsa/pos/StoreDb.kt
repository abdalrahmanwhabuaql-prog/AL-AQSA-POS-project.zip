package com.alqsa.pos

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

 data class Product(
    val id: Long, val name: String, val barcode: String,
    val buyPrice: Double, val sellPrice: Double, val quantity: Int,
    val unitName: String = "قطعة", val packSize: Int = 1,
    val packSellPrice: Double = sellPrice * packSize
)
data class SaleLine(val id: Long, val productName: String, val quantity: Int,
                    val unitPrice: Double, val unitCost: Double, val createdAt: String)
data class Expense(val id: Long, val title: String, val amount: Double, val createdAt: String)
data class Summary(val sales: Double, val cost: Double, val expenses: Double,
                   val products: Int, val stockUnits: Int, val lowStock: Int)
data class PartyBalance(val partyType: String, val partyName: String, val balance: Double)
data class DebtEntry(val id: Long, val partyType: String, val partyName: String, val amount: Double, val note: String, val createdAt: String)
data class CashSummary(val opening: Double, val balance: Double, val cashIn: Double, val cashOut: Double)

class StoreDb(context: Context) : SQLiteOpenHelper(context, "alqsa_pos.db", null, 4) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE products(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
            barcode TEXT NOT NULL DEFAULT '', buy_price REAL NOT NULL DEFAULT 0,
            sell_price REAL NOT NULL DEFAULT 0, quantity INTEGER NOT NULL DEFAULT 0,
            unit_name TEXT NOT NULL DEFAULT 'قطعة', pack_size INTEGER NOT NULL DEFAULT 1,
            pack_sell_price REAL NOT NULL DEFAULT 0)""")
        db.execSQL("""CREATE TABLE sales(
            id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL,
            product_name TEXT NOT NULL, quantity INTEGER NOT NULL,
            unit_price REAL NOT NULL, unit_cost REAL NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        createExtraTables(db)
    }

    private fun createExtraTables(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS purchases(
            id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL,
            product_name TEXT NOT NULL, quantity INTEGER NOT NULL,
            unit_cost REAL NOT NULL, total REAL NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS expenses(
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
            amount REAL NOT NULL, note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS cash_moves(
            id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL,
            amount REAL NOT NULL, note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS sale_headers(
            id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT NOT NULL,
            has_invoice INTEGER NOT NULL DEFAULT 0, customer_name TEXT NOT NULL DEFAULT '',
            total REAL NOT NULL, discount REAL NOT NULL DEFAULT 0,
            paid REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS debt_entries(
            id INTEGER PRIMARY KEY AUTOINCREMENT, party_type TEXT NOT NULL,
            party_name TEXT NOT NULL, amount REAL NOT NULL, note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS debt_payments(
            id INTEGER PRIMARY KEY AUTOINCREMENT, party_type TEXT NOT NULL,
            party_name TEXT NOT NULL, amount REAL NOT NULL, note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS app_settings(
            setting_key TEXT PRIMARY KEY, setting_value TEXT NOT NULL DEFAULT '')""")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE products ADD COLUMN unit_name TEXT NOT NULL DEFAULT 'قطعة'")
            db.execSQL("ALTER TABLE products ADD COLUMN pack_size INTEGER NOT NULL DEFAULT 1")
            createExtraTables(db)
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE products ADD COLUMN pack_sell_price REAL NOT NULL DEFAULT 0")
            db.execSQL("UPDATE products SET pack_sell_price=sell_price*pack_size")
        }
        if (oldVersion < 4) createExtraTables(db)
    }

    fun products(): List<Product> {
        val list = mutableListOf<Product>()
        readableDatabase.rawQuery("SELECT * FROM products ORDER BY name COLLATE NOCASE", null).use { c ->
            while (c.moveToNext()) list += Product(c.getLong(c.getColumnIndexOrThrow("id")), c.getString(c.getColumnIndexOrThrow("name")), c.getString(c.getColumnIndexOrThrow("barcode")), c.getDouble(c.getColumnIndexOrThrow("buy_price")), c.getDouble(c.getColumnIndexOrThrow("sell_price")), c.getInt(c.getColumnIndexOrThrow("quantity")), c.getString(c.getColumnIndexOrThrow("unit_name")), c.getInt(c.getColumnIndexOrThrow("pack_size")), c.getDouble(c.getColumnIndexOrThrow("pack_sell_price")))
        }
        return list
    }

    fun addProduct(name: String, barcode: String, buy: Double, sell: Double, qty: Int,
                   unitName: String = "قطعة", packSize: Int = 1, packSellPrice: Double = sell * packSize) {
        val v = ContentValues().apply { put("name", name.trim()); put("barcode", barcode.trim()); put("buy_price", buy); put("sell_price", sell); put("quantity", qty); put("unit_name", unitName); put("pack_size", packSize.coerceAtLeast(1)); put("pack_sell_price", packSellPrice) }
        writableDatabase.insert("products", null, v)
    }
    fun updateProduct(id: Long, name: String, barcode: String, buy: Double, sell: Double, qty: Int, unitName: String, packSize: Int, packSellPrice: Double = sell * packSize) {
        val v = ContentValues().apply { put("name", name.trim()); put("barcode", barcode.trim()); put("buy_price", buy); put("sell_price", sell); put("quantity", qty); put("unit_name", unitName); put("pack_size", packSize.coerceAtLeast(1)); put("pack_sell_price", packSellPrice) }
        writableDatabase.update("products", v, "id=?", arrayOf(id.toString()))
    }

    /** Records a completed sale atomically. Quantity is always stored in base pieces. */
    fun checkout(lines: List<Pair<Product, Pair<Int, Double>>>, hasInvoice: Boolean, paid: Double,
                 discount: Double = 0.0, customerName: String = ""): Long {
        if (lines.isEmpty() || lines.any { it.second.first <= 0 }) return -1
        val totalBefore = lines.sumOf { it.second.first * it.second.second }
        val total = (totalBefore - discount).coerceAtLeast(0.0)
        if (paid < 0 || paid > total + 0.0001) return -1
        val db = writableDatabase
        db.beginTransaction()
        try {
            lines.forEach { (p, pair) ->
                val current = findProduct(db, p.id) ?: return -1
                if (current.quantity < pair.first) return -1
            }
            val head = ContentValues().apply {
                put("invoice_no", "AQ-${System.currentTimeMillis()}"); put("has_invoice", if (hasInvoice) 1 else 0)
                put("customer_name", customerName); put("total", total); put("discount", discount); put("paid", paid)
            }
            val saleId = db.insert("sale_headers", null, head)
            lines.forEach { (p, pair) ->
                val qty = pair.first; val price = pair.second
                db.execSQL("UPDATE products SET quantity=quantity-? WHERE id=?", arrayOf(qty, p.id))
                val v = ContentValues().apply { put("product_id", p.id); put("product_name", p.name); put("quantity", qty); put("unit_price", price); put("unit_cost", p.buyPrice) }
                db.insert("sales", null, v)
            }
            if (paid > 0) { val v = ContentValues().apply { put("kind", "بيع"); put("amount", paid); put("note", "مبيعات رقم $saleId") }; db.insert("cash_moves", null, v) }
            val due = total - paid
            if (due > 0.0001) {
                val v = ContentValues().apply { put("party_type", "customer"); put("party_name", customerName.ifBlank { "زبون نقدي/آجل غير محدد" }); put("amount", due); put("note", "مستحق من بيع رقم $saleId") }
                db.insert("debt_entries", null, v)
            }
            db.setTransactionSuccessful(); return saleId
        } finally { db.endTransaction() }
    }

    fun sell(productId: Long, quantity: Int, unitPrice: Double? = null): Boolean {
        val p = products().firstOrNull { it.id == productId } ?: return false
        return checkout(listOf(p to (quantity to (unitPrice ?: p.sellPrice))), false, quantity * (unitPrice ?: p.sellPrice)) > 0
    }
    fun sellOne(product: Product) = sell(product.id, 1)

    fun addPurchase(productId: Long, quantity: Int, unitCost: Double): Boolean = addPurchase(productId, quantity, unitCost, "", 0.0)
    fun addPurchase(productId: Long, quantity: Int, unitCost: Double, supplier: String, paid: Double): Boolean {
        if (quantity <= 0 || unitCost < 0 || paid < 0 || paid > quantity * unitCost) return false
        val db = writableDatabase; db.beginTransaction()
        try {
            val p = findProduct(db, productId) ?: return false
            val total = quantity * unitCost
            val newQty = p.quantity + quantity
            val avgCost = if (newQty == 0) unitCost else ((p.quantity * p.buyPrice) + total) / newQty
            db.execSQL("UPDATE products SET quantity=?, buy_price=? WHERE id=?", arrayOf(newQty, avgCost, productId))
            val v = ContentValues().apply { put("product_id", productId); put("product_name", p.name); put("quantity", quantity); put("unit_cost", unitCost); put("total", total) }; db.insert("purchases", null, v)
            if (paid > 0) { val c = ContentValues().apply { put("kind", "شراء بضاعة"); put("amount", paid); put("note", "مورد: $supplier") }; db.insert("cash_moves", null, c) }
            val due = total - paid
            if (due > 0.0001 && supplier.isNotBlank()) { val d = ContentValues().apply { put("party_type", "supplier"); put("party_name", supplier.trim()); put("amount", due); put("note", "مستحق مشتريات") }; db.insert("debt_entries", null, d) }
            db.setTransactionSuccessful(); return true
        } finally { db.endTransaction() }
    }

    fun addExpense(title: String, amount: Double, note: String = "") {
        if (title.isBlank() || amount <= 0) return
        val v = ContentValues().apply { put("title", title.trim()); put("amount", amount); put("note", note) }; writableDatabase.insert("expenses", null, v)
        addCashMove("مصروف", amount, title)
    }
    fun addCashMove(kind: String, amount: Double, note: String = "") { if (amount <= 0) return; val v = ContentValues().apply { put("kind", kind); put("amount", amount); put("note", note) }; writableDatabase.insert("cash_moves", null, v) }

    fun addDebt(partyType: String, name: String, amount: Double, note: String = "") {
        if (name.isBlank() || amount <= 0) return
        val v = ContentValues().apply { put("party_type", partyType); put("party_name", name.trim()); put("amount", amount); put("note", note) }; writableDatabase.insert("debt_entries", null, v)
    }
    fun payDebt(partyType: String, name: String, amount: Double, note: String = ""): Boolean {
        if (name.isBlank() || amount <= 0 || amount > balance(partyType, name) + 0.0001) return false
        val v = ContentValues().apply { put("party_type", partyType); put("party_name", name.trim()); put("amount", amount); put("note", note) }; writableDatabase.insert("debt_payments", null, v)
        addCashMove(if (partyType == "customer") "تحصيل دين" else "سداد مورد", amount, name)
        return true
    }
    fun balances(): List<PartyBalance> {
        val sql = "SELECT party_type,party_name,(SELECT COALESCE(SUM(amount),0) FROM debt_entries e WHERE e.party_type=d.party_type AND e.party_name=d.party_name)-(SELECT COALESCE(SUM(amount),0) FROM debt_payments p WHERE p.party_type=d.party_type AND p.party_name=d.party_name) balance FROM debt_entries d GROUP BY party_type,party_name HAVING balance>0.0001 ORDER BY party_name"
        val out = mutableListOf<PartyBalance>(); readableDatabase.rawQuery(sql, null).use { c -> while (c.moveToNext()) out += PartyBalance(c.getString(0), c.getString(1), c.getDouble(2)) }; return out
    }
    fun balance(type: String, name: String): Double {
        val sql = "SELECT COALESCE((SELECT SUM(amount) FROM debt_entries WHERE party_type=? AND party_name=?),0)-COALESCE((SELECT SUM(amount) FROM debt_payments WHERE party_type=? AND party_name=?),0)"
        return readableDatabase.rawQuery(sql, arrayOf(type,name,type,name)).use { if (it.moveToFirst()) it.getDouble(0) else 0.0 }
    }
    fun debtHistory(): List<DebtEntry> {
        val out = mutableListOf<DebtEntry>(); readableDatabase.rawQuery("SELECT id,party_type,party_name,amount,note,created_at FROM debt_entries ORDER BY id DESC LIMIT 100", null).use { c -> while (c.moveToNext()) out += DebtEntry(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getString(4),c.getString(5)) }; return out
    }
    fun cashSummary(): CashSummary {
        val db = readableDatabase
        fun sum(sql: String, args: Array<String>? = null) = db.rawQuery(sql,args).use { if (it.moveToFirst()) it.getDouble(0) else 0.0 }
        val opening = sum("SELECT COALESCE(CAST(setting_value AS REAL),0) FROM app_settings WHERE setting_key='opening_cash'")
        val ins = sum("SELECT COALESCE(SUM(amount),0) FROM cash_moves WHERE kind IN ('بيع','تحصيل دين','إيداع','رأس مال')")
        val outs = sum("SELECT COALESCE(SUM(amount),0) FROM cash_moves WHERE kind IN ('شراء بضاعة','مصروف','سداد مورد','سحب شخصي','سحب')")
        return CashSummary(opening, opening + ins - outs, ins, outs)
    }
    fun setOpeningCash(amount: Double) { val v = ContentValues().apply { put("setting_key", "opening_cash"); put("setting_value", amount.toString()) }; writableDatabase.insertWithOnConflict("app_settings", null, v, SQLiteDatabase.CONFLICT_REPLACE) }

    fun summary(): Summary {
        val db = readableDatabase
        fun scalar(sql: String): Double = db.rawQuery(sql, null).use { if (it.moveToFirst()) it.getDouble(0) else 0.0 }
        return Summary(scalar("SELECT COALESCE(SUM(quantity*unit_price),0) FROM sales WHERE date(created_at)=date('now','localtime')"), scalar("SELECT COALESCE(SUM(quantity*unit_cost),0) FROM sales WHERE date(created_at)=date('now','localtime')"), scalar("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE date(created_at)=date('now','localtime')"), scalar("SELECT COUNT(*) FROM products").toInt(), scalar("SELECT COALESCE(SUM(quantity),0) FROM products").toInt(), scalar("SELECT COUNT(*) FROM products WHERE quantity<=3").toInt())
    }
    fun salesHistory(limit: Int = 100): List<SaleLine> {
        val list = mutableListOf<SaleLine>(); readableDatabase.rawQuery("SELECT id,product_name,quantity,unit_price,unit_cost,created_at FROM sales ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())).use { c -> while (c.moveToNext()) list += SaleLine(c.getLong(0),c.getString(1),c.getInt(2),c.getDouble(3),c.getDouble(4),c.getString(5)) }; return list
    }
    fun expenses(): List<Expense> {
        val list = mutableListOf<Expense>(); readableDatabase.rawQuery("SELECT id,title,amount,created_at FROM expenses ORDER BY id DESC LIMIT 100", null).use { c -> while (c.moveToNext()) list += Expense(c.getLong(0),c.getString(1),c.getDouble(2),c.getString(3)) }; return list
    }
    fun todaySalesTotal(): Double = summary().sales
    private fun findProduct(db: SQLiteDatabase, id: Long): Product? {
        db.rawQuery("SELECT id,name,barcode,buy_price,sell_price,quantity,unit_name,pack_size,pack_sell_price FROM products WHERE id=?", arrayOf(id.toString())).use { c ->
            if (!c.moveToFirst()) return null
            return Product(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getDouble(4),c.getInt(5),c.getString(6),c.getInt(7),c.getDouble(8))
        }
    }
}
