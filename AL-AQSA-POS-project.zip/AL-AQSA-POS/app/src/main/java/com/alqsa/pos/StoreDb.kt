package com.alqsa.pos

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Product(
    val id: Long, val name: String, val barcode: String,
    val buyPrice: Double, val sellPrice: Double, val quantity: Int,
    val unitName: String = "قطعة", val packSize: Int = 1
)

data class SaleLine(val id: Long, val productName: String, val quantity: Int,
                    val unitPrice: Double, val unitCost: Double, val createdAt: String)
data class Expense(val id: Long, val title: String, val amount: Double, val createdAt: String)
data class Summary(val sales: Double, val cost: Double, val expenses: Double,
                   val products: Int, val stockUnits: Int, val lowStock: Int)

class StoreDb(context: Context) : SQLiteOpenHelper(context, "alqsa_pos.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE products(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
            barcode TEXT NOT NULL DEFAULT '', buy_price REAL NOT NULL DEFAULT 0,
            sell_price REAL NOT NULL DEFAULT 0, quantity INTEGER NOT NULL DEFAULT 0,
            unit_name TEXT NOT NULL DEFAULT 'قطعة', pack_size INTEGER NOT NULL DEFAULT 1)""")
        db.execSQL("""CREATE TABLE sales(
            id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL,
            product_name TEXT NOT NULL, quantity INTEGER NOT NULL,
            unit_price REAL NOT NULL, unit_cost REAL NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        createExtraTables(db)
    }

    private fun createExtraTables(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS purchases(
            id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL,
            product_name TEXT NOT NULL, quantity INTEGER NOT NULL,
            unit_cost REAL NOT NULL, total REAL NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS expenses(
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
            amount REAL NOT NULL, note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS cash_moves(
            id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL,
            amount REAL NOT NULL, note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE products ADD COLUMN unit_name TEXT NOT NULL DEFAULT 'قطعة'")
            db.execSQL("ALTER TABLE products ADD COLUMN pack_size INTEGER NOT NULL DEFAULT 1")
            createExtraTables(db)
        }
    }

    fun products(): List<Product> {
        val list = mutableListOf<Product>()
        readableDatabase.rawQuery("SELECT * FROM products ORDER BY name COLLATE NOCASE", null).use { c ->
            while (c.moveToNext()) list += Product(
                c.getLong(c.getColumnIndexOrThrow("id")),
                c.getString(c.getColumnIndexOrThrow("name")),
                c.getString(c.getColumnIndexOrThrow("barcode")),
                c.getDouble(c.getColumnIndexOrThrow("buy_price")),
                c.getDouble(c.getColumnIndexOrThrow("sell_price")),
                c.getInt(c.getColumnIndexOrThrow("quantity")),
                c.getString(c.getColumnIndexOrThrow("unit_name")),
                c.getInt(c.getColumnIndexOrThrow("pack_size"))
            )
        }
        return list
    }

    fun addProduct(name: String, barcode: String, buy: Double, sell: Double,
                   qty: Int, unitName: String = "قطعة", packSize: Int = 1) {
        val v = ContentValues().apply {
            put("name", name.trim()); put("barcode", barcode.trim())
            put("buy_price", buy); put("sell_price", sell); put("quantity", qty)
            put("unit_name", unitName); put("pack_size", packSize.coerceAtLeast(1))
        }
        writableDatabase.insert("products", null, v)
    }

    fun updateProduct(id: Long, name: String, barcode: String, buy: Double, sell: Double,
                      qty: Int, unitName: String, packSize: Int) {
        val v = ContentValues().apply {
            put("name", name.trim()); put("barcode", barcode.trim())
            put("buy_price", buy); put("sell_price", sell); put("quantity", qty)
            put("unit_name", unitName); put("pack_size", packSize.coerceAtLeast(1))
        }
        writableDatabase.update("products", v, "id=?", arrayOf(id.toString()))
    }

    fun sell(productId: Long, quantity: Int): Boolean {
        if (quantity <= 0) return false
        val db = writableDatabase
        db.beginTransaction()
        try {
            val p = findProduct(db, productId) ?: return false
            if (p.quantity < quantity) return false
            db.execSQL("UPDATE products SET quantity=quantity-? WHERE id=?", arrayOf(quantity, productId))
            val v = ContentValues().apply {
                put("product_id", p.id); put("product_name", p.name); put("quantity", quantity)
                put("unit_price", p.sellPrice); put("unit_cost", p.buyPrice)
            }
            db.insert("sales", null, v)
            db.setTransactionSuccessful()
            return true
        } finally { db.endTransaction() }
    }

    fun sellOne(product: Product) = sell(product.id, 1)

    fun addPurchase(productId: Long, quantity: Int, unitCost: Double): Boolean {
        if (quantity <= 0 || unitCost < 0) return false
        val db = writableDatabase
        db.beginTransaction()
        try {
            val p = findProduct(db, productId) ?: return false
            db.execSQL("UPDATE products SET quantity=quantity+?, buy_price=? WHERE id=?",
                arrayOf(quantity, unitCost, productId))
            val v = ContentValues().apply {
                put("product_id", productId); put("product_name", p.name)
                put("quantity", quantity); put("unit_cost", unitCost); put("total", quantity * unitCost)
            }
            db.insert("purchases", null, v)
            db.setTransactionSuccessful()
            return true
        } finally { db.endTransaction() }
    }

    fun addExpense(title: String, amount: Double, note: String = "") {
        if (title.isBlank() || amount <= 0) return
        val v = ContentValues().apply { put("title", title.trim()); put("amount", amount); put("note", note) }
        writableDatabase.insert("expenses", null, v)
    }

    fun addCashMove(kind: String, amount: Double, note: String = "") {
        if (amount <= 0) return
        val v = ContentValues().apply { put("kind", kind); put("amount", amount); put("note", note) }
        writableDatabase.insert("cash_moves", null, v)
    }

    fun summary(): Summary {
        val db = readableDatabase
        fun scalar(sql: String): Double = db.rawQuery(sql, null).use { if (it.moveToFirst()) it.getDouble(0) else 0.0 }
        return Summary(
            scalar("SELECT COALESCE(SUM(quantity*unit_price),0) FROM sales WHERE date(created_at)=date('now','localtime')"),
            scalar("SELECT COALESCE(SUM(quantity*unit_cost),0) FROM sales WHERE date(created_at)=date('now','localtime')"),
            scalar("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE date(created_at)=date('now','localtime')"),
            scalar("SELECT COUNT(*) FROM products").toInt(),
            scalar("SELECT COALESCE(SUM(quantity),0) FROM products").toInt(),
            scalar("SELECT COUNT(*) FROM products WHERE quantity<=3").toInt()
        )
    }

    fun salesHistory(limit: Int = 100): List<SaleLine> {
        val list = mutableListOf<SaleLine>()
        readableDatabase.rawQuery("SELECT id,product_name,quantity,unit_price,unit_cost,created_at FROM sales ORDER BY id DESC LIMIT ?",
            arrayOf(limit.toString())).use { c ->
            while (c.moveToNext()) list += SaleLine(c.getLong(0), c.getString(1), c.getInt(2),
                c.getDouble(3), c.getDouble(4), c.getString(5))
        }
        return list
    }

    fun expenses(): List<Expense> {
        val list = mutableListOf<Expense>()
        readableDatabase.rawQuery("SELECT id,title,amount,created_at FROM expenses ORDER BY id DESC LIMIT 100", null).use { c ->
            while (c.moveToNext()) list += Expense(c.getLong(0), c.getString(1), c.getDouble(2), c.getString(3))
        }
        return list
    }

    fun todaySalesTotal(): Double = summary().sales

    private fun findProduct(db: SQLiteDatabase, id: Long): Product? {
        db.rawQuery("SELECT id,name,barcode,buy_price,sell_price,quantity,unit_name,pack_size FROM products WHERE id=?",
            arrayOf(id.toString())).use { c ->
            if (!c.moveToFirst()) return null
            return Product(c.getLong(0), c.getString(1), c.getString(2), c.getDouble(3),
                c.getDouble(4), c.getInt(5), c.getString(6), c.getInt(7))
        }
    }
}
