package com.alqsa.pos

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

 data class Product(
    val id: Long, val name: String, val barcode: String,
    val buyPrice: Double, val sellPrice: Double, val quantity: Int,
    val unitName: String = "قطعة", val packSize: Int = 1,
    val packSellPrice: Double = sellPrice * packSize, val category: String = "عام"
)
data class SaleLine(val id: Long, val productName: String, val quantity: Int,
                    val unitPrice: Double, val unitCost: Double, val createdAt: String)
data class Expense(val id: Long, val title: String, val amount: Double, val createdAt: String)
data class Summary(val sales: Double, val cost: Double, val expenses: Double,
                   val products: Int, val stockUnits: Int, val lowStock: Int,
                   val monthSales: Double = 0.0, val monthCost: Double = 0.0, val monthExpenses: Double = 0.0)
data class PartyBalance(val partyType: String, val partyName: String, val balance: Double)
data class DebtEntry(val id: Long, val partyType: String, val partyName: String, val amount: Double, val note: String, val createdAt: String)
data class SaleHeader(val id: Long, val invoiceNo: String, val hasInvoice: Boolean, val customerName: String,
                      val customerPhone: String, val total: Double, val discount: Double, val paid: Double, val createdAt: String,
                      val returnedValue: Double = 0.0)
data class InvoiceLine(val id: Long, val productId: Long, val productName: String, val quantity: Int,
                       val unitPrice: Double, val unitCost: Double, val returnedQty: Int = 0)
data class PeriodReport(val sales: Double, val returns: Double, val cost: Double, val expenses: Double,
                        val invoices: Int, val top: List<Pair<String, Int>>)
data class CashSummary(val opening: Double, val balance: Double, val cashIn: Double, val cashOut: Double)

class StoreDb(context: Context) : SQLiteOpenHelper(context, "alqsa_pos.db", null, 8) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE products(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
            barcode TEXT NOT NULL DEFAULT '', buy_price REAL NOT NULL DEFAULT 0,
            sell_price REAL NOT NULL DEFAULT 0, quantity INTEGER NOT NULL DEFAULT 0,
            unit_name TEXT NOT NULL DEFAULT 'قطعة', pack_size INTEGER NOT NULL DEFAULT 1,
            pack_sell_price REAL NOT NULL DEFAULT 0, category TEXT NOT NULL DEFAULT 'عام')""")
        db.execSQL("""CREATE TABLE sales(
            id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL,
            product_name TEXT NOT NULL, quantity INTEGER NOT NULL,
            unit_price REAL NOT NULL, unit_cost REAL NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, sale_id INTEGER NOT NULL DEFAULT 0,
            returned_qty INTEGER NOT NULL DEFAULT 0)""")
        createExtraTables(db)
    }

    private fun createExtraTables(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS categories(name TEXT PRIMARY KEY)""")
        db.execSQL("INSERT OR IGNORE INTO categories(name) VALUES ('عام')")
        db.execSQL("""CREATE TABLE IF NOT EXISTS purchases(
            id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL,
            product_name TEXT NOT NULL, quantity INTEGER NOT NULL,
            unit_cost REAL NOT NULL, total REAL NOT NULL,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, invoice_uri TEXT NOT NULL DEFAULT '', delivery_uri TEXT NOT NULL DEFAULT '')""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS expenses(
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
            amount REAL NOT NULL, note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS cash_moves(
            id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL,
            amount REAL NOT NULL, note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS sale_headers(
            id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT NOT NULL,
            has_invoice INTEGER NOT NULL DEFAULT 0, customer_name TEXT NOT NULL DEFAULT '', customer_phone TEXT NOT NULL DEFAULT '',
            total REAL NOT NULL, discount REAL NOT NULL DEFAULT 0,
            paid REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            returned_value REAL NOT NULL DEFAULT 0, refunded_cash REAL NOT NULL DEFAULT 0)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS sale_returns(
            id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL, line_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL, product_name TEXT NOT NULL, quantity INTEGER NOT NULL,
            unit_price REAL NOT NULL, unit_cost REAL NOT NULL, refund_value REAL NOT NULL,
            cash_refund REAL NOT NULL DEFAULT 0, debt_credit REAL NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS debt_entries(
            id INTEGER PRIMARY KEY AUTOINCREMENT, party_type TEXT NOT NULL,
            party_name TEXT NOT NULL, amount REAL NOT NULL, note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS debt_payments(
            id INTEGER PRIMARY KEY AUTOINCREMENT, party_type TEXT NOT NULL,
            party_name TEXT NOT NULL, amount REAL NOT NULL, note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS app_settings(
            setting_key TEXT PRIMARY KEY, setting_value TEXT NOT NULL DEFAULT '')""")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE products ADD COLUMN unit_name TEXT NOT NULL DEFAULT 'قطعة'")
            db.execSQL("ALTER TABLE products ADD COLUMN pack_size INTEGER NOT NULL DEFAULT 1")
            createExtraTables(db)
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE products ADD COLUMN pack_sell_price REAL NOT NULL DEFAULT 0")
            db.execSQL("UPDATE products SET pack_sell_price=sell_price*pack_size")
        }
        if (oldVersion < 4) createExtraTables(db)
        if (oldVersion < 5) {
            db.execSQL("ALTER TABLE products ADD COLUMN category TEXT NOT NULL DEFAULT 'عام'")
            if (!hasColumn(db, "sale_headers", "customer_phone")) db.execSQL("ALTER TABLE sale_headers ADD COLUMN customer_phone TEXT NOT NULL DEFAULT ''")
            createExtraTables(db)
        }
        if (oldVersion < 6) {
            if (!hasColumn(db, "purchases", "invoice_uri")) db.execSQL("ALTER TABLE purchases ADD COLUMN invoice_uri TEXT NOT NULL DEFAULT ''")
            if (!hasColumn(db, "purchases", "delivery_uri")) db.execSQL("ALTER TABLE purchases ADD COLUMN delivery_uri TEXT NOT NULL DEFAULT ''")
        }
        if (oldVersion < 7) migrateSalesToInvoices(db)
        if (oldVersion < 8) migrateReturns(db)
    }

    /** v7: link every sale line to its invoice header (sales.sale_id -> sale_headers.id). Additive, nothing is dropped. */
    private fun migrateSalesToInvoices(db: SQLiteDatabase) {
        if (!hasColumn(db, "sales", "sale_id")) db.execSQL("ALTER TABLE sales ADD COLUMN sale_id INTEGER NOT NULL DEFAULT 0")
        // Old rows were written in the same transaction as their header, so they share the same timestamp.
        // Link only when exactly one header matches that timestamp...
        db.execSQL("""UPDATE sales SET sale_id=(SELECT h.id FROM sale_headers h WHERE h.created_at=sales.created_at)
            WHERE sale_id=0 AND (SELECT COUNT(*) FROM sale_headers h WHERE h.created_at=sales.created_at)=1""")
        // ...and keep the link only if the lines add up to the invoice total, otherwise leave those lines unlinked.
        db.execSQL("""UPDATE sales SET sale_id=0 WHERE sale_id IN (
            SELECT h.id FROM sale_headers h WHERE ABS(h.total + h.discount -
            (SELECT COALESCE(SUM(s.quantity*s.unit_price),0) FROM sales s WHERE s.sale_id=h.id)) > 0.01)""")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sales_sale_id ON sales(sale_id)")
    }

    /** v8: returns/cancellations. Additive only. */
    private fun migrateReturns(db: SQLiteDatabase) {
        if (!hasColumn(db, "sales", "returned_qty")) db.execSQL("ALTER TABLE sales ADD COLUMN returned_qty INTEGER NOT NULL DEFAULT 0")
        if (!hasColumn(db, "sale_headers", "returned_value")) db.execSQL("ALTER TABLE sale_headers ADD COLUMN returned_value REAL NOT NULL DEFAULT 0")
        if (!hasColumn(db, "sale_headers", "refunded_cash")) db.execSQL("ALTER TABLE sale_headers ADD COLUMN refunded_cash REAL NOT NULL DEFAULT 0")
        createExtraTables(db)
    }

    private fun hasColumn(db: SQLiteDatabase, table: String, column: String): Boolean {
        db.rawQuery("PRAGMA table_info($table)", null).use { c -> while (c.moveToNext()) if (c.getString(c.getColumnIndexOrThrow("name")) == column) return true }
        return false
    }

    fun categories(): List<String> {
        val out = mutableListOf<String>(); readableDatabase.rawQuery("SELECT name FROM categories ORDER BY name", null).use { c -> while (c.moveToNext()) out += c.getString(0) }; return out
    }
    fun addCategory(name: String) { if (name.isNotBlank()) { val v = ContentValues().apply { put("name", name.trim()) }; writableDatabase.insertWithOnConflict("categories", null, v, SQLiteDatabase.CONFLICT_IGNORE) } }

    fun products(): List<Product> {
        val list = mutableListOf<Product>()
        readableDatabase.rawQuery("SELECT * FROM products ORDER BY name COLLATE NOCASE", null).use { c ->
            while (c.moveToNext()) list += Product(c.getLong(c.getColumnIndexOrThrow("id")), c.getString(c.getColumnIndexOrThrow("name")), c.getString(c.getColumnIndexOrThrow("barcode")), c.getDouble(c.getColumnIndexOrThrow("buy_price")), c.getDouble(c.getColumnIndexOrThrow("sell_price")), c.getInt(c.getColumnIndexOrThrow("quantity")), c.getString(c.getColumnIndexOrThrow("unit_name")), c.getInt(c.getColumnIndexOrThrow("pack_size")), c.getDouble(c.getColumnIndexOrThrow("pack_sell_price")), c.getString(c.getColumnIndexOrThrow("category")))
        }
        return list
    }

    fun addProduct(name: String, barcode: String, buy: Double, sell: Double, qty: Int,
                   unitName: String = "قطعة", packSize: Int = 1, packSellPrice: Double = sell * packSize, category: String = "عام") {
        val v = ContentValues().apply { put("name", name.trim()); put("barcode", barcode.trim()); put("buy_price", buy); put("sell_price", sell); put("quantity", qty); put("unit_name", unitName); put("pack_size", packSize.coerceAtLeast(1)); put("pack_sell_price", packSellPrice); put("category", category.ifBlank { "عام" }) }
        writableDatabase.insert("products", null, v)
        addCategory(category)
    }
    fun updateProduct(id: Long, name: String, barcode: String, buy: Double, sell: Double, qty: Int, unitName: String, packSize: Int, packSellPrice: Double = sell * packSize, category: String = "عام") {
        val v = ContentValues().apply { put("name", name.trim()); put("barcode", barcode.trim()); put("buy_price", buy); put("sell_price", sell); put("quantity", qty); put("unit_name", unitName); put("pack_size", packSize.coerceAtLeast(1)); put("pack_sell_price", packSellPrice); put("category", category.ifBlank { "عام" }) }
        writableDatabase.update("products", v, "id=?", arrayOf(id.toString()))
        addCategory(category)
    }

    /** Records a completed sale atomically. Quantity is always stored in base pieces. */
    fun checkout(lines: List<Pair<Product, Pair<Int, Double>>>, hasInvoice: Boolean, paid: Double,
                 discount: Double = 0.0, customerName: String = "", customerPhone: String = ""): Long {
        if (lines.isEmpty() || lines.any { it.second.first <= 0 }) return -1
        val totalBefore = lines.sumOf { it.second.first * it.second.second }
        val total = (totalBefore - discount).coerceAtLeast(0.0)
        if (paid < 0 || paid > total + 0.0001) return -1
        val db = writableDatabase
        db.beginTransaction()
        try {
            lines.forEach { (p, pair) ->
                val current = findProduct(db, p.id) ?: return -1
                if (current.quantity < pair.first) return -1
            }
            val head = ContentValues().apply {
                put("invoice_no", "AQ-${System.currentTimeMillis()}"); put("has_invoice", if (hasInvoice) 1 else 0)
                put("customer_name", customerName); put("customer_phone", customerPhone); put("total", total); put("discount", discount); put("paid", paid)
            }
            val saleId = db.insert("sale_headers", null, head)
            lines.forEach { (p, pair) ->
                val qty = pair.first; val price = pair.second
                db.execSQL("UPDATE products SET quantity=quantity-? WHERE id=?", arrayOf(qty, p.id))
                val v = ContentValues().apply { put("product_id", p.id); put("product_name", p.name); put("quantity", qty); put("unit_price", price); put("unit_cost", p.buyPrice); put("sale_id", saleId) }
                db.insert("sales", null, v)
            }
            if (paid > 0) { val v = ContentValues().apply { put("kind", "بيع"); put("amount", paid); put("note", "مبيعات رقم $saleId") }; db.insert("cash_moves", null, v) }
            val due = total - paid
            if (due > 0.0001) {
                val v = ContentValues().apply { put("party_type", "customer"); put("party_name", customerName.ifBlank { "زبون نقدي/آجل غير محدد" }); put("amount", due); put("note", "مستحق من بيع رقم $saleId") }
                db.insert("debt_entries", null, v)
            }
            db.setTransactionSuccessful(); return saleId
        } finally { db.endTransaction() }
    }

    fun sell(productId: Long, quantity: Int, unitPrice: Double? = null): Boolean {
        val p = products().firstOrNull { it.id == productId } ?: return false
        return checkout(listOf(p to (quantity to (unitPrice ?: p.sellPrice))), false, quantity * (unitPrice ?: p.sellPrice)) > 0
    }
    fun sellOne(product: Product) = sell(product.id, 1)

    fun addPurchase(productId: Long, quantity: Int, unitCost: Double): Boolean = addPurchase(productId, quantity, unitCost, "", 0.0)
    fun addPurchase(productId: Long, quantity: Int, unitCost: Double, supplier: String, paid: Double, invoiceUri: String = "", deliveryUri: String = ""): Boolean {
        if (quantity <= 0 || unitCost < 0 || paid < 0 || paid > quantity * unitCost) return false
        val db = writableDatabase; db.beginTransaction()
        try {
            val p = findProduct(db, productId) ?: return false
            val total = quantity * unitCost
            val newQty = p.quantity + quantity
            val avgCost = if (newQty == 0) unitCost else ((p.quantity * p.buyPrice) + total) / newQty
            db.execSQL("UPDATE products SET quantity=?, buy_price=? WHERE id=?", arrayOf(newQty, avgCost, productId))
            val v = ContentValues().apply { put("product_id", productId); put("product_name", p.name); put("quantity", quantity); put("unit_cost", unitCost); put("total", total); put("invoice_uri", invoiceUri); put("delivery_uri", deliveryUri) }; db.insert("purchases", null, v)
            if (paid > 0) { val c = ContentValues().apply { put("kind", "شراء بضاعة"); put("amount", paid); put("note", "مورد: $supplier") }; db.insert("cash_moves", null, c) }
            val due = total - paid
            if (due > 0.0001 && supplier.isNotBlank()) { val d = ContentValues().apply { put("party_type", "supplier"); put("party_name", supplier.trim()); put("amount", due); put("note", "مستحق مشتريات") }; db.insert("debt_entries", null, d) }
            db.setTransactionSuccessful(); return true
        } finally { db.endTransaction() }
    }

    fun addExpense(title: String, amount: Double, note: String = "") {
        if (title.isBlank() || amount <= 0) return
        val v = ContentValues().apply { put("title", title.trim()); put("amount", amount); put("note", note) }; writableDatabase.insert("expenses", null, v)
        addCashMove("مصروف", amount, title)
    }
    fun addCashMove(kind: String, amount: Double, note: String = "") { if (amount <= 0) return; val v = ContentValues().apply { put("kind", kind); put("amount", amount); put("note", note) }; writableDatabase.insert("cash_moves", null, v) }

    fun addDebt(partyType: String, name: String, amount: Double, note: String = "") {
        if (name.isBlank() || amount <= 0) return
        val v = ContentValues().apply { put("party_type", partyType); put("party_name", name.trim()); put("amount", amount); put("note", note) }; writableDatabase.insert("debt_entries", null, v)
    }
    fun payDebt(partyType: String, name: String, amount: Double, note: String = ""): Boolean {
        if (name.isBlank() || amount <= 0 || amount > balance(partyType, name) + 0.0001) return false
        val v = ContentValues().apply { put("party_type", partyType); put("party_name", name.trim()); put("amount", amount); put("note", note) }; writableDatabase.insert("debt_payments", null, v)
        addCashMove(if (partyType == "customer") "تحصيل دين" else "سداد مورد", amount, name)
        return true
    }
    fun balances(): List<PartyBalance> {
        val sql = "SELECT party_type,party_name,(SELECT COALESCE(SUM(amount),0) FROM debt_entries e WHERE e.party_type=d.party_type AND e.party_name=d.party_name)-(SELECT COALESCE(SUM(amount),0) FROM debt_payments p WHERE p.party_type=d.party_type AND p.party_name=d.party_name) balance FROM debt_entries d GROUP BY party_type,party_name HAVING balance>0.0001 ORDER BY party_name"
        val out = mutableListOf<PartyBalance>(); readableDatabase.rawQuery(sql, null).use { c -> while (c.moveToNext()) out += PartyBalance(c.getString(0), c.getString(1), c.getDouble(2)) }; return out
    }
    fun balance(type: String, name: String): Double = balanceIn(readableDatabase, type, name)
    private fun balanceIn(db: SQLiteDatabase, type: String, name: String): Double {
        val sql = "SELECT COALESCE((SELECT SUM(amount) FROM debt_entries WHERE party_type=? AND party_name=?),0)-COALESCE((SELECT SUM(amount) FROM debt_payments WHERE party_type=? AND party_name=?),0)"
        return db.rawQuery(sql, arrayOf(type,name,type,name)).use { if (it.moveToFirst()) it.getDouble(0) else 0.0 }
    }
    fun debtHistory(): List<DebtEntry> {
        val out = mutableListOf<DebtEntry>(); readableDatabase.rawQuery("SELECT id,party_type,party_name,amount,note,created_at FROM debt_entries ORDER BY id DESC LIMIT 100", null).use { c -> while (c.moveToNext()) out += DebtEntry(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getString(4),c.getString(5)) }; return out
    }
    fun cashSummary(): CashSummary {
        val db = readableDatabase
        fun sum(sql: String, args: Array<String>? = null) = db.rawQuery(sql,args).use { if (it.moveToFirst()) it.getDouble(0) else 0.0 }
        val opening = sum("SELECT COALESCE(CAST(setting_value AS REAL),0) FROM app_settings WHERE setting_key='opening_cash'")
        val ins = sum("SELECT COALESCE(SUM(amount),0) FROM cash_moves WHERE kind IN ('بيع','تحصيل دين','إيداع','رأس مال')")
        val outs = sum("SELECT COALESCE(SUM(amount),0) FROM cash_moves WHERE kind IN ('شراء بضاعة','مصروف','سداد مورد','سحب شخصي','سحب','مرتجع مبيعات')")
        return CashSummary(opening, opening + ins - outs, ins, outs)
    }
    fun setOpeningCash(amount: Double) { val v = ContentValues().apply { put("setting_key", "opening_cash"); put("setting_value", amount.toString()) }; writableDatabase.insertWithOnConflict("app_settings", null, v, SQLiteDatabase.CONFLICT_REPLACE) }

    fun summary(): Summary {
        val db = readableDatabase
        fun scalar(sql: String): Double = db.rawQuery(sql, null).use { if (it.moveToFirst()) it.getDouble(0) else 0.0 }
        val today = "date(created_at,'localtime')=date('now','localtime')"
        val month = "strftime('%Y-%m',created_at,'localtime')=strftime('%Y-%m','now','localtime')"
        // net of returns: sales lines minus returned lines, each counted on its own date
        fun net(expr: String, cond: String) = scalar("SELECT (SELECT COALESCE(SUM($expr),0) FROM sales WHERE $cond)-(SELECT COALESCE(SUM($expr),0) FROM sale_returns WHERE $cond)")
        return Summary(
            net("quantity*unit_price", today), net("quantity*unit_cost", today),
            scalar("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE $today"),
            scalar("SELECT COUNT(*) FROM products").toInt(), scalar("SELECT COALESCE(SUM(quantity),0) FROM products").toInt(),
            scalar("SELECT COUNT(*) FROM products WHERE quantity<=3").toInt(),
            net("quantity*unit_price", month), net("quantity*unit_cost", month),
            scalar("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE $month")
        )
    }

    /** Local date (yyyy-MM-dd) computed by SQLite, e.g. dateOf("start of month", "-1 day"). */
    fun dateOf(vararg modifiers: String): String {
        val sql = "SELECT date('now','localtime'" + ",?".repeat(modifiers.size) + ")"
        return readableDatabase.rawQuery(sql, arrayOf(*modifiers)).use { if (it.moveToFirst()) it.getString(0) else "" }
    }

    fun periodReport(from: String, to: String): PeriodReport {
        val db = readableDatabase
        val cond = "date(created_at,'localtime') BETWEEN ? AND ?"
        val args = arrayOf(from, to)
        fun scalar(sql: String): Double = db.rawQuery(sql, args).use { if (it.moveToFirst()) it.getDouble(0) else 0.0 }
        val gross = scalar("SELECT COALESCE(SUM(quantity*unit_price),0) FROM sales WHERE $cond")
        val grossCost = scalar("SELECT COALESCE(SUM(quantity*unit_cost),0) FROM sales WHERE $cond")
        val retValue = scalar("SELECT COALESCE(SUM(quantity*unit_price),0) FROM sale_returns WHERE $cond")
        val retCost = scalar("SELECT COALESCE(SUM(quantity*unit_cost),0) FROM sale_returns WHERE $cond")
        val exp = scalar("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE $cond")
        val inv = scalar("SELECT COUNT(*) FROM sale_headers WHERE $cond").toInt()
        val top = mutableListOf<Pair<String, Int>>()
        db.rawQuery("SELECT product_name, SUM(quantity-returned_qty) q FROM sales WHERE $cond GROUP BY product_id, product_name HAVING q>0 ORDER BY q DESC LIMIT 5", args).use { c ->
            while (c.moveToNext()) top += c.getString(0) to c.getInt(1)
        }
        return PeriodReport(gross - retValue, retValue, grossCost - retCost, exp, inv, top)
    }

    /** Products still in stock that have not sold in the last [days] days. */
    fun slowProducts(days: Int = 60): List<Pair<String, Int>> {
        val out = mutableListOf<Pair<String, Int>>()
        readableDatabase.rawQuery("""SELECT name, quantity FROM products p WHERE quantity>0 AND NOT EXISTS (
            SELECT 1 FROM sales s WHERE s.product_id=p.id AND date(s.created_at,'localtime')>=date('now','localtime',?))
            ORDER BY quantity DESC LIMIT 30""", arrayOf("-$days day")).use { c -> while (c.moveToNext()) out += c.getString(0) to c.getInt(1) }
        return out
    }

    fun salesHistory(limit: Int = 100): List<SaleLine> {
        val list = mutableListOf<SaleLine>(); readableDatabase.rawQuery("SELECT id,product_name,quantity,unit_price,unit_cost,created_at FROM sales ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())).use { c -> while (c.moveToNext()) list += SaleLine(c.getLong(0),c.getString(1),c.getInt(2),c.getDouble(3),c.getDouble(4),c.getString(5)) }; return list
    }
    fun saleHeaders(limit: Int = 200): List<SaleHeader> {
        val out = mutableListOf<SaleHeader>()
        readableDatabase.rawQuery("SELECT id,invoice_no,has_invoice,customer_name,customer_phone,total,discount,paid,created_at,returned_value FROM sale_headers ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())).use { c ->
            while (c.moveToNext()) out += SaleHeader(c.getLong(0), c.getString(1), c.getInt(2) == 1, c.getString(3), c.getString(4), c.getDouble(5), c.getDouble(6), c.getDouble(7), c.getString(8), c.getDouble(9))
        }
        return out
    }
    fun saleLines(saleId: Long): List<InvoiceLine> {
        val out = mutableListOf<InvoiceLine>()
        readableDatabase.rawQuery("SELECT id,product_id,product_name,quantity,unit_price,unit_cost,returned_qty FROM sales WHERE sale_id=? ORDER BY id", arrayOf(saleId.toString())).use { c ->
            while (c.moveToNext()) out += InvoiceLine(c.getLong(0), c.getLong(1), c.getString(2), c.getInt(3), c.getDouble(4), c.getDouble(5), c.getInt(6))
        }
        return out
    }

    /** Returns [qty] pieces of one invoice line to stock and reverses cash / customer debt. */
    fun returnLine(lineId: Long, qty: Int): Boolean = returnLines(listOf(lineId to qty))

    /** Cancels what is left of an invoice (every line not yet returned). */
    fun cancelSale(saleId: Long): Boolean {
        val items = saleLines(saleId).filter { it.quantity - it.returnedQty > 0 }.map { it.id to (it.quantity - it.returnedQty) }
        return items.isNotEmpty() && returnLines(items)
    }

    private fun returnLines(items: List<Pair<Long, Int>>): Boolean {
        if (items.isEmpty() || items.any { it.second <= 0 }) return false
        val db = writableDatabase
        db.beginTransaction()
        try {
            for ((lineId, qty) in items) { if (!returnOne(db, lineId, qty)) return false }
            db.setTransactionSuccessful(); return true
        } finally { db.endTransaction() }
    }

    private fun returnOne(db: SQLiteDatabase, lineId: Long, qty: Int): Boolean {
        var productId = 0L; var name = ""; var lineQty = 0; var returnedQty = 0
        var price = 0.0; var cost = 0.0; var saleId = 0L
        db.rawQuery("SELECT product_id,product_name,quantity,returned_qty,unit_price,unit_cost,sale_id FROM sales WHERE id=?", arrayOf(lineId.toString())).use { c ->
            if (!c.moveToFirst()) return false
            productId = c.getLong(0); name = c.getString(1); lineQty = c.getInt(2); returnedQty = c.getInt(3)
            price = c.getDouble(4); cost = c.getDouble(5); saleId = c.getLong(6)
        }
        if (saleId <= 0 || qty <= 0 || qty > lineQty - returnedQty) return false
        var total = 0.0; var discount = 0.0; var paid = 0.0; var returnedValue = 0.0; var refundedCash = 0.0; var customer = ""
        db.rawQuery("SELECT total,discount,paid,returned_value,refunded_cash,customer_name FROM sale_headers WHERE id=?", arrayOf(saleId.toString())).use { c ->
            if (!c.moveToFirst()) return false
            total = c.getDouble(0); discount = c.getDouble(1); paid = c.getDouble(2)
            returnedValue = c.getDouble(3); refundedCash = c.getDouble(4); customer = c.getString(5)
        }
        // value of the returned pieces, scaled by any invoice discount
        val gross = total + discount
        val ratio = if (gross > 0.0001) total / gross else 1.0
        var newReturned = returnedValue + Math.round(qty * price * ratio * 100.0) / 100.0
        if (total - newReturned < 0.011) newReturned = total          // avoid 0.01 leftovers
        val refundValue = newReturned - returnedValue
        val oldEffective = (total - returnedValue).coerceAtLeast(0.0)
        val newEffective = (total - newReturned).coerceAtLeast(0.0)
        val debtCredit = (oldEffective - paid).coerceAtLeast(0.0) - (newEffective - paid).coerceAtLeast(0.0)
        val cashRefund = ((paid - newEffective).coerceAtLeast(0.0) - refundedCash).coerceAtLeast(0.0)

        val party = customer.ifBlank { "زبون نقدي/آجل غير محدد" }
        // the customer may already have paid this debt separately: never push the ledger below zero, refund the rest in cash
        val debtApplied = minOf(debtCredit, balanceIn(db, "customer", party).coerceAtLeast(0.0))
        val extraCash = debtCredit - debtApplied
        val cashOut = cashRefund + extraCash

        db.execSQL("UPDATE products SET quantity=quantity+? WHERE id=?", arrayOf(qty, productId))
        db.execSQL("UPDATE sales SET returned_qty=returned_qty+? WHERE id=?", arrayOf(qty, lineId))
        db.execSQL("UPDATE sale_headers SET returned_value=?, refunded_cash=refunded_cash+? WHERE id=?", arrayOf(newReturned, cashRefund, saleId))
        if (debtApplied > 0.0001) {
            val v = ContentValues().apply { put("party_type", "customer"); put("party_name", party); put("amount", debtApplied); put("note", "مرتجع من فاتورة رقم $saleId") }
            db.insert("debt_payments", null, v)
        }
        if (cashOut > 0.0001) {
            val v = ContentValues().apply { put("kind", "مرتجع مبيعات"); put("amount", cashOut); put("note", "مرتجع من فاتورة رقم $saleId") }
            db.insert("cash_moves", null, v)
        }
        val r = ContentValues().apply {
            put("sale_id", saleId); put("line_id", lineId); put("product_id", productId); put("product_name", name)
            put("quantity", qty); put("unit_price", price); put("unit_cost", cost); put("refund_value", refundValue)
            put("cash_refund", cashOut); put("debt_credit", debtApplied)
        }
        db.insert("sale_returns", null, r)
        return true
    }
    fun expenses(): List<Expense> {
        val list = mutableListOf<Expense>(); readableDatabase.rawQuery("SELECT id,title,amount,created_at FROM expenses ORDER BY id DESC LIMIT 100", null).use { c -> while (c.moveToNext()) list += Expense(c.getLong(0),c.getString(1),c.getDouble(2),c.getString(3)) }; return list
    }
    fun todaySalesTotal(): Double = summary().sales
    private fun findProduct(db: SQLiteDatabase, id: Long): Product? {
        db.rawQuery("SELECT id,name,barcode,buy_price,sell_price,quantity,unit_name,pack_size,pack_sell_price,category FROM products WHERE id=?", arrayOf(id.toString())).use { c ->
            if (!c.moveToFirst()) return null
            return Product(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getDouble(4),c.getInt(5),c.getString(6),c.getInt(7),c.getDouble(8),c.getString(9))
        }
    }
}
