package com.alqsa.pos

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Product(
    val id: Long,
    val name: String,
    val barcode: String,
    val buyPrice: Double,
    val sellPrice: Double,
    val quantity: Int
)

class StoreDb(context: Context) : SQLiteOpenHelper(context, "alqsa_pos.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE products(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                barcode TEXT NOT NULL DEFAULT '',
                buy_price REAL NOT NULL DEFAULT 0,
                sell_price REAL NOT NULL DEFAULT 0,
                quantity INTEGER NOT NULL DEFAULT 0
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE sales(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                product_name TEXT NOT NULL,
                quantity INTEGER NOT NULL,
                unit_price REAL NOT NULL,
                unit_cost REAL NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun products(): List<Product> {
        val result = mutableListOf<Product>()
        readableDatabase.rawQuery("SELECT * FROM products ORDER BY name COLLATE NOCASE", null).use { c ->
            while (c.moveToNext()) {
                result += Product(
                    c.getLong(c.getColumnIndexOrThrow("id")),
                    c.getString(c.getColumnIndexOrThrow("name")),
                    c.getString(c.getColumnIndexOrThrow("barcode")),
                    c.getDouble(c.getColumnIndexOrThrow("buy_price")),
                    c.getDouble(c.getColumnIndexOrThrow("sell_price")),
                    c.getInt(c.getColumnIndexOrThrow("quantity"))
                )
            }
        }
        return result
    }

    fun addProduct(name: String, barcode: String, buy: Double, sell: Double, qty: Int) {
        val values = ContentValues().apply {
            put("name", name.trim())
            put("barcode", barcode.trim())
            put("buy_price", buy)
            put("sell_price", sell)
            put("quantity", qty)
        }
        writableDatabase.insert("products", null, values)
    }

    fun sellOne(product: Product): Boolean {
        val db = writableDatabase
        db.beginTransaction()
        return try {
            val current = db.rawQuery("SELECT quantity FROM products WHERE id=?", arrayOf(product.id.toString())).use {
                if (it.moveToFirst()) it.getInt(0) else 0
            }
            if (current <= 0) return false
            db.execSQL("UPDATE products SET quantity=quantity-1 WHERE id=?", arrayOf(product.id))
            val values = ContentValues().apply {
                put("product_id", product.id)
                put("product_name", product.name)
                put("quantity", 1)
                put("unit_price", product.sellPrice)
                put("unit_cost", product.buyPrice)
            }
            db.insert("sales", null, values)
            db.setTransactionSuccessful()
            true
        } finally {
            db.endTransaction()
        }
    }

    fun todaySalesTotal(): Double {
        readableDatabase.rawQuery(
            "SELECT COALESCE(SUM(quantity * unit_price),0) FROM sales WHERE date(created_at)=date('now','localtime')",
            null
        ).use { return if (it.moveToFirst()) it.getDouble(0) else 0.0 }
    }
}
