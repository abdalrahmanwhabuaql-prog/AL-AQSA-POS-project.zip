# AL-AQSA POS – Final development base

Arabic-first offline Android point-of-sale app for مكتبة الأقصى – عبدالرحمن.

## Current source changes in this work pass
- Database upgraded to schema v4 with additive migration (does not drop the existing product/sales tables).
- Product packaging model retained: base-piece stock, pack size, piece and pack prices.
- Sale confirmation now asks for quick invoice or sale without invoice, and records paid amount; unpaid remainder is posted to customer debt.
- Customer and supplier debt ledgers with partial payments.
- Cashbox opening balance and manual deposits/withdrawals.
- Purchases support supplier name and amount paid; outstanding supplier amount is recorded as debt.
- Average purchase cost is recalculated when stock is replenished.
- CameraX + ML Kit barcode scanner source remains included.

## Build
The GitHub Actions workflow builds a debug APK using Gradle 8.9, JDK 17, Android SDK 35.
Run the workflow manually or push to `main`. Download artifact `AL-AQSA-POS-debug`.

## Important status
This is an in-progress source update, not a certified final APK. Build and device testing are still required. Before installing an update over an existing installation, export/back up app data if possible. Do not uninstall the old app because Android app data may be lost.

## Not yet completed/verified
- Invoice preview/share screen and invoice numbering presentation.
- Returns/cancellations with full accounting reversal.
- Database export/import backup and restore UI.
- Full monthly reports and comprehensive end-to-end tests.
- Camera scanning must be tested on the target Android phone.

Core accounting operations are local; no ecommerce module is included.
