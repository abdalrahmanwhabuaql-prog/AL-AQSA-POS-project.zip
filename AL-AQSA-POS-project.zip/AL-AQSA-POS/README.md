# AL-AQSA POS – Final development base

Arabic-first offline Android point-of-sale app for مكتبة الأقصى – عبدالرحمن.

## Current source changes in this work pass
- Database upgraded to schema v6 with additive migration (does not drop the existing product/sales tables).
- Product packaging model retained: base-piece stock, pack size, piece and pack prices.
- Sale confirmation now asks for quick invoice or sale without invoice, and records paid amount; unpaid remainder is posted to customer debt.
- Customer and supplier debt ledgers with partial payments.
- Cashbox opening balance and manual deposits/withdrawals.
- Purchases support supplier name and amount paid; outstanding supplier amount is recorded as debt.
- Average purchase cost is recalculated when stock is replenished.
- CameraX + ML Kit barcode scanner is available in cashier and purchases screens.
- Cashier cart supports multiple products in one sale; invoice/no-invoice selection, optional customer name and phone, and automatic customer debt.
- Product categories are stored with products and can be entered when creating or editing a product.
- Purchases screen can search by product name/barcode, scan a barcode with the camera, and open the new-product form without leaving purchases.
- Purchases can attach supplier invoice and delivery-note files (images or PDF); their document URIs are stored with the purchase record.
- Backup screen exports the local SQLite database to a user-selected location and can validate and restore a selected SQLite backup.
- Reports show daily and current-month sales, cost, expenses, and estimated net profit.
- GitHub Actions now builds the Android project from the repository root rather than expecting a nested ZIP archive.

## Build
The GitHub Actions workflow builds a debug APK using Gradle 8.9, JDK 17, Android SDK 35.
Run the workflow manually or push to `main`. Download artifact `AL-AQSA-POS-debug`.

## Important status
This is an in-progress source update, not a certified final APK. Build and device testing are still required. Before installing an update over an existing installation, export/back up app data if possible. Do not uninstall the old app because Android app data may be lost.

## Not yet completed/verified
- Invoice preview/share screen and invoice numbering presentation.
- Purchase-document attachment preview/opening from the purchase history (the selected document references are saved with each purchase).
- Google account sign-in and cloud sync/backup (requires OAuth/Firebase project configuration).
- Returns/cancellations with full accounting reversal.
- Backup/restore is implemented in source but still needs real-device testing, including restore from older backup versions.
- Date-range/custom-period reports, returns/cancellations with full accounting reversal, and comprehensive end-to-end tests.
- Camera scanning must be tested on the target Android phone.

Core accounting operations are local; no ecommerce module is included.
