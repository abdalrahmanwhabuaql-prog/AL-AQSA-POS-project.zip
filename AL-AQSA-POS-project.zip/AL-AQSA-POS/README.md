# AL-AQSA POS – Final development base

Arabic-first offline Android point-of-sale app for مكتبة الأقصى – عبدالرحمن.

## Current source changes in this work pass
- Database upgraded to schema v6 with additive migration (does not drop the existing product/sales tables).
- Product packaging model retained: base-piece stock, pack size, piece and pack prices.
- Sale confirmation now asks for quick invoice or sale without invoice, and records paid amount; unpaid remainder is posted to customer debt.
- Customer and supplier debt ledgers with partial payments.
- Cashbox opening balance and manual deposits/withdrawals.
- Purchases support supplier name and amount paid; outstanding supplier amount is recorded as debt.
- Average purchase cost is recalculated when stock is replenished.
- CameraX + ML Kit barcode scanner is available in cashier and purchases screens.
- Cashier cart supports multiple products in one sale; invoice/no-invoice selection, optional customer name and phone, and automatic customer debt.
- Product categories are stored with products and can be entered when creating or editing a product.
- Purchases screen can search by product name/barcode, scan a barcode with the camera, and open the new-product form without leaving purchases.
- Purchases can attach supplier invoice and delivery-note files (images or PDF); their document URIs are stored with the purchase record.
- Backup screen exports the local SQLite database to a user-selected location and can validate and restore a selected SQLite backup.
- Reports show daily and current-month sales, cost, expenses, and estimated net profit.
- GitHub Actions now builds the Android project from the repository root rather than expecting a nested ZIP archive.

## v1.5.0 changes
- Scanner: flashlight toggle for low light (shown only on phones with a flash unit).
- Payment methods (كاش / جوال بي / بال بي / بنك فلسطين) on every payment: sale checkout, purchase invoices, expenses, debt collection/payment, manual cash moves, and refund of returns. Stored in `cash_moves.method` (+ `sale_headers.pay_method`, `purchase_headers.pay_method`, `debt_payments.method`), DB schema v10; old rows default to cash.
- Cashbox page is now "الصندوق والمحافظ": balance per method (cash drawer keeps the opening balance), manual moves per account, and transfers between accounts.
- Debts page redesigned: totals (owed to us / owed by us), search, sort, party cards, full account statement per party with running balance, collect/pay with method and "pay full balance", share statement, call customer.

## v1.4.0 changes
- Purchases are now full supplier invoices: supplier name (required, with suggestions), optional supplier invoice number, many products per invoice, one payment for the whole invoice (the remainder becomes a supplier debt), attachments, and a purchases history screen with expandable items. Stock and average cost update atomically (DB schema v9: `purchase_headers`, `purchases.purchase_id`).
- Duplicate barcode warning (and save blocked) when adding/editing a product.
- Per-product low-stock alert threshold (`products.min_stock`, default 3), used by the home summary and the reports.

## v1.3.0 changes
- Returns and full-invoice cancellation (Invoices screen): stock is restored; cash refund / customer-debt credit are computed automatically (DB schema v8, tables `sale_returns`, columns `returned_qty`, `returned_value`, `refunded_cash`). Reports are net of returns.
- Invoice sharing: text (WhatsApp) and PDF (share / print) via FileProvider.
- New "تقارير الفترات" screen: today / yesterday / 7 days / this month / last month / custom range, top products, low stock, slow-moving stock.
- Bottom bar reduced to 5 items with a "المزيد" menu; app launcher icon added; invoice times shown in local time; daily/monthly totals now use local dates (previously UTC).

## v1.2.0 changes
- Product add/edit dialog now has a camera barcode-scan button (inventory screen), with permission handling.
- Database schema v7: `sales.sale_id` links every sale line to its invoice (`sale_headers.id`). Old sales are linked best-effort (only when unambiguous and totals match); the rest stay unlinked.
- New "الفواتير" screen: invoice history with tap-to-expand line items, customer, paid and remaining debt.
- Home screen is scrollable.

## v1.2.0 changes
- Product add/edit dialog now has a camera barcode-scan button (inventory screen), with permission handling.
- Database schema v7: `sales.sale_id` links every sale line to its invoice (`sale_headers.id`). Old sales are linked best-effort (only when unambiguous and totals match); the rest stay unlinked.
- New "الفواتير" screen: invoice history with tap-to-expand line items, customer, paid and remaining debt.
- Home screen is scrollable.

## Build
The GitHub Actions workflow builds a debug APK using Gradle 8.9, JDK 17, Android SDK 35.
Run the workflow manually or push to `main`. Download artifact `AL-AQSA-POS-debug`.

## Important status
This is an in-progress source update, not a certified final APK. Build and device testing are still required. Before installing an update over an existing installation, export/back up app data if possible. Do not uninstall the old app because Android app data may be lost.

## Not yet completed/verified
- Invoice preview/share screen and invoice numbering presentation.
- Purchase-document attachment preview/opening from the purchase history (the selected document references are saved with each purchase).
- Google account sign-in and cloud sync/backup (requires OAuth/Firebase project configuration).
- Returns/cancellations with full accounting reversal.
- Backup/restore is implemented in source but still needs real-device testing, including restore from older backup versions.
- Date-range/custom-period reports, returns/cancellations with full accounting reversal, and comprehensive end-to-end tests.
- Camera scanning must be tested on the target Android phone.

Core accounting operations are local; no ecommerce module is included.
